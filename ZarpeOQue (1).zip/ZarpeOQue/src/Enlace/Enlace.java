/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Enlace;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Jonathan
 */
public class Enlace {
    
    public static final String url = "jdbc:mysql://localhost:3306/zarpeoque";
    public static final String usuario = "root";
    public static final String contra = "1221";
    
    public Connection getConexion(){
        Connection conectar = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = (Connection) DriverManager.getConnection(url, usuario, contra);
        }
        catch(Exception e) {
            System.out.println("Ha ocurrido en ENLACE un error: " + e.getMessage());
        }
        
        return conectar;
        
    }
}
