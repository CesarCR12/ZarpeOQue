
package zarpeoque;

import Enlace.Enlace;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ListaProductos extends javax.swing.JFrame {
    static Enlace conexion = new Enlace();
    static Connection conectar = conexion.getConexion();
    static DefaultTableModel model;
    static PreparedStatement pst;
    static ResultSet rs;
    Snack todoProducto = new Snack();

    public ListaProductos() {
        initComponents();
        setLocationRelativeTo(null);
        recuperar();
    }
    
    public static int verificarID(String ID){
        int estado = -1;
        String consultar = "select * from producto where id = ?";
        
        try {
            conectar = conexion.getConexion();
            pst = conectar.prepareStatement(consultar);
            pst.setString(1, ID);
            rs = pst.executeQuery();
            if (rs.next()) {
                estado = 1;
            }//final if
        }//final try 
        catch (Exception e) {
            System.out.println("Error en verificarID: "+e.getMessage()); 
        }//final catch 
        finally {
            cerrarRecursos();
        }//final finally
        return estado;
    }//final del metodo verificarID
    
    public static int verificarCategoria(String categoria){
        int estado = -1;
        String consultar = "select * from producto where categoria = ?";
        
        try {
            conectar = conexion.getConexion();
            pst = conectar.prepareStatement(consultar);
            pst.setString(1, categoria);
            rs = pst.executeQuery();
            if (rs.next()) {
                estado = 1;
            }//final if
        }//final try 
        catch (Exception e) {
            System.out.println("Error en verificarCategoria: "+e.getMessage()); 
        }//final catch 
        finally {
            cerrarRecursos();
        }//final finally
        return estado;
    }//final del metodo verificarID

    void recuperar(){
    String consultar = "select * from producto";
    limpiarTabla();

    try {
        conectar = conexion.getConexion();
        pst = conectar.prepareStatement(consultar);
        rs = pst.executeQuery(consultar);
        Object[] producto = new Object[9];
        model = (DefaultTableModel) resultados.getModel();
        while (rs.next()) {                
            producto[0] = rs.getInt("id");
            producto[1] = rs.getString("nombre");
            producto[2] = rs.getInt("cantidad");
            producto[3] = rs.getString("descripcion");
            producto[4] = rs.getDouble("precioNeto");
            producto[5] = rs.getDouble("precioBruto");
            producto[6] = rs.getString("categoria");
            producto[7] = rs.getBoolean("estado");
            producto[8] = rs.getDate("caducidad");
            model.addRow(producto);
        }//final while
        resultados.setModel(model);

    }//final try
    catch (SQLException e) {
        System.out.println("Error recuperando información: "+e.getMessage());
        limpiarTabla();
    }//final catch 
    finally {
        
        cerrarRecursos();
    }//final finally
}//final metodo recuperar
        
    public static void agregar(String id, String nombre, int cantidad, String descripcion, String categoria, double precioNeto, double precioBruto,  boolean estado, LocalDate caducidad){
        try {
            if (nombre.equals("")) {
                JOptionPane.showMessageDialog
                (null, "Debes llenar todos los espacios.");
            }//final if
            else{
                int estadoInt = estado ? 1 : 0;  // Si estado es true, estadoInt será 1; de lo contrario, será 0
                if (caducidad != null) {
                    String consultar = "insert into producto("
                    + "id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad)"
                    +"values('"+id+"','"+nombre+"','"+cantidad+"','"+descripcion+"','"+categoria+"','"+precioNeto+"','"+precioBruto+"','"+estadoInt+"','"+caducidad+"')";
                    conectar = conexion.getConexion();
                    pst = conectar.prepareStatement(consultar);
                    pst.executeUpdate(consultar);
                }//final if
                JOptionPane.showMessageDialog(null, "Productos agregados exitosamente.");
            }//Final else
        }//final try
        catch (Exception e){
            System.out.println("Error while adding data: "+ e.getMessage());
        }//final catch
        finally {
            cerrarRecursos();
        }//final finally
    }//final add
        
    public static void eliminar(String id){
        try {
        String consultar = "delete from producto where id = "+id;

        conectar = conexion.getConexion();
        pst = conectar.prepareStatement(consultar);
        pst.executeUpdate(consultar);
        }
        catch (Exception e){
            System.out.println("Error while deleting data: "+ e.getMessage());
        }
        finally {
            
            cerrarRecursos();
        }
    }//final del metodo eliminar
    
    public static void modificarPrecio(String ID, double precioNeto, double precioBruto){
        try{
        String consultar = "update producto set precioNeto = '"+precioNeto+"', precioBruto = '"+precioBruto+"' where id = "+ID;
        conectar = conexion.getConexion();
        pst = conectar.prepareStatement(consultar);
        pst.executeUpdate(consultar);
        }//final try
        catch (Exception e){
            System.out.println("Error while modyfing data: "+e.getMessage());
        }//final catch
        finally{
            cerrarRecursos();
        }//final finally
        
    }//final del metodo modificarPrecio
        
    void limpiarTabla(){
        for (int i = 0; i < resultados.getRowCount(); i++) {
            model.removeRow(i);
            i--;
        }//final for
    }//final metodo limpiarTabla
    
    public static void cerrarRecursos(){
            if(rs != null)
            {
                try
                {
                    rs.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
            //Vamos a limpiar la memoria destinada para la consulta
            if(pst != null)
            {
                try
                {
                    pst.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
            //Vamos a cerrar la conexión
            if(conectar != null)
            {
                try
                {
                    conectar.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
    }//final metodo cerrarRecursos
    
    public static void actualizarCantidad(String id, int cantidad) {
        try {

            String actualizarCantidad = "update producto set cantidad = ? where id = ?";

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setInt(1, cantidad);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar la cantidad: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
        
    }//final metodo actualizarCantidad
    
    public static void actualizarEstado(String id, boolean estado){
        try {

            String actualizarCantidad = "update producto set estado = ? where id = ?";

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setBoolean(1, estado);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar el estado: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
    }//final metodo actualizarEstado
    
    public static void actualizarPrecioNeto(String id, double precio){
        try {

            String actualizarCantidad = "update producto set precioNeto = ? where id = ?";

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setDouble(1, precio);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar el precio: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
    }//final metodo actualizarPrecioNeto
    
    public static void actualizarPrecioBruto(String id, double precio){
        try {

            String actualizarCantidad = "update producto set precioBruto = ? where id = ?";

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setDouble(1, precio);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar el precio: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
    }//final metodo actualizarPrecioBruto
    
    public static void ejecutarConsulta(String consulta) {
        try {
            conectar = conexion.getConexion();
            pst  = conectar.prepareStatement(consulta);
            pst.executeUpdate(consulta);
            System.out.println("Consulta ejecutada correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final metodo ejecutarConsulta
    
    public static void actualizarCaducidad(String id, LocalDate caducidad){
        try {

            String actualizarCantidad = "update producto set caducidad = ? where id = ?";
            
            //este pasa de un LocalDate a un Date
            Date fechaCaducidad = Date.valueOf(caducidad);

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setDate(1, fechaCaducidad);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar la caducidad: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
    }//final metodo actualizarCaducidad
    
    public static void cargarDatosSnack() {
        String consulta = "select * from producto WHERE categoria = 'snack'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[1].length; i++) {
                    if (ZarpeOQue.productos[1][i] == null) {
                        ZarpeOQue.productos[1][i] = new Snack(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosBebidas() {
        String consulta = "select * from producto WHERE categoria = 'bebida'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[0].length; i++) {
                    if (ZarpeOQue.productos[0][i] == null) {
                        ZarpeOQue.productos[0][i] = new Snack(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosCarne() {
        String consulta = "select * from producto WHERE categoria = 'carne'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[10].length; i++) {
                    if (ZarpeOQue.productos[10][i] == null) {
                        ZarpeOQue.productos[10][i] = new Carne(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosCongelados() {
        String consulta = "select * from producto where categoria = 'congelado'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[9].length; i++) {
                    if (ZarpeOQue.productos[9][i] == null) {
                        ZarpeOQue.productos[9][i] = new Congelado(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosEnlatados() {
        String consulta = "select * from producto WHERE categoria = 'enlatado'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[8].length; i++) {
                    if (ZarpeOQue.productos[8][i] == null) {
                        ZarpeOQue.productos[8][i] = new Enlatado(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosFarmaco() {
        String consulta = "select * from producto WHERE categoria = 'farmaco'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[7].length; i++) {
                    if (ZarpeOQue.productos[7][i] == null) {
                        ZarpeOQue.productos[7][i] = new Farmaco(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosFrutaVerdura() {
        String consulta = "select * from producto WHERE categoria = 'fruta/verdura'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[6].length; i++) {
                    if (ZarpeOQue.productos[6][i] == null) {
                        ZarpeOQue.productos[6][i] = new Fruta_Verdura(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosHarina() {
        String consulta = "select * from producto WHERE categoria = 'harina'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[5].length; i++) {
                    if (ZarpeOQue.productos[5][i] == null) {
                        ZarpeOQue.productos[5][i] = new Harina(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosLacteo() {
        String consulta = "select * from producto WHERE categoria = 'lacteo'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[4].length; i++) {
                    if (ZarpeOQue.productos[4][i] == null) {
                        ZarpeOQue.productos[4][i] = new Lacteo(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosLegumbre() {
        String consulta = "select * from producto WHERE categoria = 'legumbre'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[3].length; i++) {
                    if (ZarpeOQue.productos[3][i] == null) {
                        ZarpeOQue.productos[3][i] = new Legumbre(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
    public static void cargarDatosLicor() {
        String consulta = "select * from producto WHERE categoria = 'licor'";
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[2].length; i++) {
                    if (ZarpeOQue.productos[2][i] == null) {
                        ZarpeOQue.productos[2][i] = new Licor(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }//final catch
        finally{
            cerrarRecursos();
        }//Final finally
    }//final cargarDatos
    
     /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jScrollPane1 = new javax.swing.JScrollPane();
        resultados = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();

        jMenu1.setText("jMenu1");

        jMenu2.setText("jMenu2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        resultados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "nombre", "cantidad", "descripcion", "precioNeto", "precioBruto", "categoria", "estado", "caducidad"
            }
        ));
        jScrollPane1.setViewportView(resultados);

        jLabel1.setFont(new java.awt.Font("SansSerif", 0, 36)); // NOI18N
        jLabel1.setText("Lista de Productos");

        jButton1.setText("Verificar Caducidad");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Eliminar Caducados");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Cambiar Precio");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Aplicar Descuento");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Quitar Descuento");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Funciones ");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Agregar");

        jButton6.setText("Snacks");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Congelados");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("Enlatados");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("Harinas");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setText("Carnes");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setText("Bebidas");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setText("Frutas / Verduras");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setText("Legumbres");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setText("Licores");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setText("Lacteos");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton16.setText("Farmacos");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jButton17.setText("SALIR");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(jSeparator2)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(231, 231, 231)
                .addComponent(jButton17)
                .addGap(18, 18, 18))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4)
                        .addGap(18, 18, 18)
                        .addComponent(jButton5)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(112, 112, 112)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton6)
                                    .addComponent(jButton14))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton7))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton13))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton8))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton11)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(186, 186, 186)
                                .addComponent(jButton12)))))
                .addContainerGap(135, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jButton17))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jLabel2)
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5)
                    .addComponent(jButton2))
                .addGap(36, 36, 36)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton6)
                        .addComponent(jButton7)
                        .addComponent(jButton13)
                        .addComponent(jButton8)
                        .addComponent(jButton9)))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton14)
                    .addComponent(jButton15)
                    .addComponent(jButton16)
                    .addComponent(jButton10)
                    .addComponent(jButton11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int contador = todoProducto.verificarCaducidad();
        JOptionPane.showMessageDialog(null, "Se han eliminado "+contador+" productos caducados.");
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        todoProducto.verificarCaducidad();
        todoProducto.eliminarProductosCaducados();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String id = Producto.pedirID();
        int estado = verificarID(id);
        if (estado != -1) {
            todoProducto.actualizarPrecio(id);
            limpiarTabla();
            recuperar();
        }//final if

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String id = Producto.pedirID();
        int estado = verificarID(id);
        if (estado != -1) {
            double descuento = Double.parseDouble(JOptionPane.showInputDialog("Digite el descuento que desea aplicar: "));
            todoProducto.aplicarDescuento(id, descuento);
            limpiarTabla();
            recuperar();
        }//final if
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        String id = Producto.pedirID();
        int estado = verificarID(id);
        if (estado != -1) {
            todoProducto.quitarDescuento(id);
            limpiarTabla();
            recuperar();
        }//final if
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        Snack.pedirMasSnacks();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        Legumbre.pedirMasLegumbres();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        Congelado.pedirMasCongelados();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        Enlatado.pedirMasEnlatados();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        Harina.pedirMasHarinas();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        Licor.pedirMasLicors();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        Lacteo.pedirMasLacteos();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        Farmaco.pedirMasFarmacos();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        Carne.pedirMasCarnes();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        Bebida.pedirMasBebidas();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        Fruta_Verdura.pedirMasFruta_Verduras();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        limpiarTabla();
        setVisible(false);
    }//GEN-LAST:event_jButton17ActionPerformed

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListaProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable resultados;
    // End of variables declaration//GEN-END:variables
}
