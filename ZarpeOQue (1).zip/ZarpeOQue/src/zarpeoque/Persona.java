
package zarpeoque;

public class Persona {
    
    // Atributos que van a tener todas las personas
    private int cedula; 
    private int edad;
    private String nombre;
    private char genero;
    
    // Constructor de la clase
    public Persona(int cedula, int edad, String nombre, char genero) {
        this.cedula = cedula;
        this.edad = edad;
        this.nombre = nombre;
        this.genero = genero;
    }
    
    // Metodos set y get de la clase
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public int getCedula() {
        return cedula;
    }

    public int getEdad() {
        return edad;
    }

    public String getNombre() {
        return nombre;
    }

    public char getGenero() {
        return genero;
    }
    
    // Fin de la clase
    
}
