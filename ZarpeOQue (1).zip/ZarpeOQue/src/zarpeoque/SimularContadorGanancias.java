
package zarpeoque;

import Enlace.Enlace;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class SimularContadorGanancias extends javax.swing.JFrame {
    
    static Enlace conexion = new Enlace();
    static Connection conectar = conexion.getConexion();
    static DefaultTableModel model;
    static PreparedStatement pst;
    static ResultSet rs;
    Snack todoProducto = new Snack();

    public SimularContadorGanancias() {
        initComponents();
        setLocationRelativeTo(null);
        recuperar();
    }
    
    void recuperar(){
        String consultar = "select * from ganancia";
        limpiarTabla();
        
        try{
            conectar = conexion.getConexion();
            pst = conectar.prepareStatement(consultar);
            rs = pst.executeQuery(consultar);
            Object[] ganancia = new Object[4];
            model = (DefaultTableModel) tabla.getModel();
            
            while (rs.next()) {
                ganancia[0] = rs.getDate("fecha");
                ganancia[1] = rs.getDouble("ventas");
                ganancia[2] = rs.getDouble("gastos");
                ganancia[3] = rs.getDouble("ganancias");
                model.addRow(ganancia);
            }//final while
            tabla.setModel(model);
            
        }//final try
        catch(SQLException e){
            System.out.println("Error recuperando información en ganancia: "+e.getMessage());
            limpiarTabla();
        }//final catch
        finally{
            cerrarRecursos();
        }//final finally
    }//final metodo recuperar
    
    public static void gananciaAgregar(double ganancias, double gastos, double ventas, LocalDate fecha){
        String consultar = "";
        try {
            Date fechaBase = Date.valueOf(fecha);
            int estado = verificarFecha(fechaBase);
            if (estado == -1) {
                    consultar = "insert into ganancia(fecha, ventas, gastos, ganancias) "
                  + "values('"+fechaBase.toLocalDate()+"','"+ventas+"','"+gastos+"','"+ganancias+"')";

            }//final if
            else{
                    consultar = "update ganancia set ganancias = '"+ganancias+"', gastos = '"+gastos+"', ventas = '"+ventas+"' where fecha = '"+fechaBase.toLocalDate()+"'";

            }//Final else

            conectar = conexion.getConexion();
            pst = conectar.prepareStatement(consultar);
            pst.executeUpdate(consultar);
            JOptionPane.showMessageDialog(null, "Reporte agregado a la base de datos.");
            }//final try
        catch (Exception e){
            System.out.println("Error agregando ganancias: "+e.getMessage());
        }//final catch
        finally {
            cerrarRecursos();
        }//final finally
    }//final metodo ganaciaAgregar
    
    void limpiarTabla(){
        for (int i = 0; i < tabla.getRowCount(); i++) {
            model.removeRow(i);
            i--;
        }//final for
    }//final metodo limpiarTabla
    
    public static void cerrarRecursos(){
            if(rs != null)
            {
                try
                {
                    rs.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
            //Vamos a limpiar la memoria destinada para la consulta
            if(pst != null)
            {
                try
                {
                    pst.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
            //Vamos a cerrar la conexión
            if(conectar != null)
            {
                try
                {
                    conectar.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
    }//final metodo cerrarRecursos
    
    public static int verificarFecha(Date fecha){
        int estado = -1;
        String consultar = "select * from ganancia where fecha = ?";
        
        try {
            conectar = conexion.getConexion();
            pst = conectar.prepareStatement(consultar);
            pst.setDate(1, fecha);
            rs = pst.executeQuery();
            if (rs.next()) {
                estado = 1;
            }//final estado
        }//final try 
        catch (Exception e) {
            System.out.println("Error en verificarFecha: "+e.getMessage()); 
        }//final catch 
        finally {
            cerrarRecursos();
        }//final finally
        return estado;
    }//final del metodo verificarFecha
    
    public static void cargarGanancia(){
        Date fechaBase = Date.valueOf(LocalDate.now());
        int estado = verificarFecha(fechaBase);
        if (estado == 1) {
            try{
            String consulta = "select * from ganancia where fecha = '"+fechaBase.toLocalDate()+"'";
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();
                while (rs.next()) {                    
                    ZarpeOQue.reporte.setFecha(rs.getDate("fecha").toLocalDate());
                    ZarpeOQue.reporte.setVentas(rs.getDouble("ventas"));
                    ZarpeOQue.reporte.setGastos(rs.getDouble("gastos"));
                    ZarpeOQue.reporte.setGanancia(rs.getDouble("ganancias"));
                }//final while
            }//final try
            catch(Exception e){
                System.out.println("Error cargando informes: "+e.getMessage());
            }//final catch
            finally{
                cerrarRecursos();
            }//Final finally
        }//final if
    }//final del metodo cargarGanancia

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        fecha = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        BotonBuscar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        SubirReporte = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Fecha", "Ventas", "Gastos", "Ganancias"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Ganancias");

        fecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fechaActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Buscar por fecha:");

        BotonBuscar.setText("Buscar");
        BotonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonBuscarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Formato requerido: YY-MM-DD");

        SubirReporte.setText("Subir Reporte");
        SubirReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubirReporteActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton7.setText("SALIR");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41)
                                .addComponent(BotonBuscar))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(SubirReporte)))
                        .addGap(0, 49, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(327, 327, 327)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotonBuscar))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(SubirReporte))
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fechaActionPerformed

    private void SubirReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubirReporteActionPerformed
        Ganancias.subirReporteBD();
        limpiarTabla();
        recuperar();
    }//GEN-LAST:event_SubirReporteActionPerformed

    private void BotonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonBuscarActionPerformed
        String buscar = fecha.getText();
        try{
            if (buscar.equals("")) {
                limpiarTabla();
                recuperar();
            }//final if
            else{
                String consultar = "select * from ganancia where fecha = '"+buscar+"'";
                conectar = conexion.getConexion();
                pst = conectar.prepareStatement(consultar);
                rs = pst.executeQuery(consultar);
                Object[] ganancia = new Object[4];
                model = (DefaultTableModel) tabla.getModel();
                limpiarTabla();
                while (rs.next()) {
                    ganancia[0] = rs.getDate("fecha");
                    ganancia[1] = rs.getDouble("ventas");
                    ganancia[2] = rs.getDouble("gastos");
                    ganancia[3] = rs.getDouble("ganancias");
                    model.addRow(ganancia);
                }//final while
                tabla.setModel(model);
            }//final else
        }//final try
        catch(Exception e){
            System.out.println("Error en formato de fecha: "+e.getMessage());
        }//final catch
        finally{
            cerrarRecursos();
        }//final finally
    }//GEN-LAST:event_BotonBuscarActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        setVisible(false);
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SimularContadorGanancias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SimularContadorGanancias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SimularContadorGanancias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SimularContadorGanancias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SimularContadorGanancias().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonBuscar;
    private javax.swing.JButton SubirReporte;
    private javax.swing.JTextField fecha;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
