
package zarpeoque;

import jdk.javadoc.doclet.Reporter;

public class Start {
    
    
    public static void instancias(){
        try{
        instanciarSiNoExisten();
        Congelado.instanciarCongelados();
        Snack.instanciarSnacks();
        Harina.instanciarHarinas();
        Lacteo.instanciarLacteos();
        Licor.instanciarLicor();
        Carne.instanciarCarnes();
        Enlatado.instanciarEnlatados();
        Legumbre.instanciarLegumbres();
        Farmaco.instanciarFarmacos();
        Bebida.instanciarBebidas();
        Fruta_Verdura.instanciarFruta_Verduras();
        SimularContadorGanancias.cargarGanancia();
        }//final try
        catch(Exception e){
            System.out.println("Error: "+e.getMessage());
        }//final catch
    }//final metodo instancias
    
    public static void app(){
        try{
        MenuPrincipal menu1 = new MenuPrincipal();
        Login.login();
        Start.instancias();
        menu1.setVisible(true);
        }//final try
        catch(Exception e){
            System.out.println("Error: "+e.getMessage());
        }//final catch
    }//final metodo app
    
    public static void instanciarSiNoExisten(){
        int estado = ListaProductos.verificarCategoria("snack");
        if (estado == -1) {
            String[] consulta = {"insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
        "values('1', 'RANCHITAS', 0, 'RANCHITAS NACHO QUESO 150g', 'snack', 1050, 1050, 1, '2023-12-14')",
    
                "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('2', 'CHIRULITOS', 0, 'CHIRULITOS TOSTY MEDIANOS 100g', 'snack', 850, 850, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('3', 'PLATANITOS', 0, 'SOLDANZA PLATANITOS 180g', 'snack', 1050, 1050, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('4', 'HARINA INTEGRAL', 0, 'HARINA INTEGRAL, IDEAL PARA PREPARAR PANES Y MASAS SALUDABLES', 'harina', 900, 900, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('5', 'HARINA DE MAÍZ', 0, 'HARINA DE MAÍZ FINA, PERFECTA PARA HACER AREPAS Y TORTILLAS', 'harina', 600, 600, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('6', 'HARINA DE ALMENDRAS', 0, 'HARINA DE ALMENDRAS, SIN GLUTEN, EXCELENTE PARA REPOSTERÍA', 'harina', 3500, 3500, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('7', 'QUESO', 0, 'QUESO DE ALTA CALIDAD, SUAVE Y DELICIOSO', 'lacteo', 2500, 2500, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('8', 'YOGURT', 0, 'YOGURT NATURAL, BAJO EN GRASAS', 'lacteo', 1200, 1200, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('9', 'LECHE', 0, 'LECHE FRESCA Y ORGANICA', 'lacteo', 1800, 1800, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('10', 'PIZZA', 0, 'PIZZA DE JAMON Y QUESO', 'congelado', 2800, 2800, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('11', 'NUGGETS', 0, 'NUGGETS DE POLLO CONGELADOS', 'congelado', 1500, 1500, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('12', 'HELADO', 0, 'HELADO DE CHOCOLATE CON GALLETA', 'congelado', 2000, 2000, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('13', 'ATUN', 0, 'ATUN ENLATADO EN ACEITE', 'enlatado', 1300, 1300, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('14', 'MAIZ', 0, 'MAIZ DULCE ENLATADO', 'enlatado', 900, 900, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('15', 'SOPA DE TOMATE', 0, 'SOPA DE TOMATE LISTA PARA CALENTAR Y SERVIR', 'enlatado', 1200, 1200, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('16', 'MANZANAS', 0, 'MANZANAS FRESCAS Y JUGOSAS', 'fruta/verdura', 400, 400, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('17', 'ZANAHORIAS', 0, 'ZANAHORIAS FRESCAS IDEALES PARA ENSALADAS', 'fruta/verdura', 300, 300, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('18', 'MANGO', 0, 'MANGO MADURO Y DULCE', 'fruta/verdura', 800, 800, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('19', 'AGUA', 0, 'AGUA NATURAL, REFRESCANTE', 'bebida', 1000, 1000, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('20', 'FRESCOLECHE', 0, 'DE FRESA (TOP)', 'bebida', 450, 450, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('21', 'COCA COLA', 0, 'SABOR ORIGINAL', 'bebida', 1000, 1000, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('22', 'FILETE DE SALMÓN', 0, 'RICO EN OMEGA-3', 'carne', 3500, 3500, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('23', 'PECHUGA DE POLLO', 0, 'LISTO PARA PREPARAR', 'carne', 2000, 2000, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('24', 'CARNE MOLIDA', 0, 'PERFECTA PARA HAMBURGUESAS', 'carne', 2500, 2500, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('25', 'IBUPROFENO', 0, 'ANALGESICO Y ANTIINFLAMATORIO', 'farmaco', 1200, 1200, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('26', 'VITAMINAS', 0, 'SUPLEMENTO DE VITAMINAS PARA LA SALUD GENERAL', 'farmaco', 1800, 1800, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('27', 'JARABE PARA LA TOS', 0, 'ALIVIO RAPIDO Y EFECTIVO', 'farmaco', 800, 800, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('28', 'CACIQUE', 0, 'GUARO CACIQUE', 'licor', 5600, 5600, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('29', 'VINO TINTO', 0, 'DE RESERVA Y COSECHA SELECCIONADA', 'licor', 4800, 4800, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('30', 'WHISKY ESCOCES', 0, 'DE MALTA Y ENVEJECIDO CON NOTAS AHUMADAS', 'licor', 7500, 7500, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('31', 'LENTEJAS', 0, 'SECAS Y RICAS EN VITAMINAS', 'legumbre', 600, 600, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('32', 'GARBANZOS', 0, 'SECOS, RICOS EN MINERALES', 'legumbre', 500, 500, 1, '2023-12-14')",

            "insert into zarpeoque.producto(id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad) " +
                    "values('33', 'FRIJOLES', 0, 'ROJOS SECOS', 'legumbre', 700, 700, 1, '2023-12-14')"};
            
            for (String consulta1 : consulta) {
                ListaProductos.ejecutarConsulta(consulta1);
            }//final for
        }//final if
    }//final metodo instanciarSiNoExisten
}
