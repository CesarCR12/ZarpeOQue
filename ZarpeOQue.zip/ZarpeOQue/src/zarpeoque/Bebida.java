
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;

public class Bebida extends Producto{

    public Bebida(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Bebida() {
    }//final construcutor vacio

    
    public static void instanciarBebidas(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[0][i] = new Bebida("AGUA", "19", "AGUA NATURAL, REFRESCANTE.","bebida", 1000, true, 1000, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[0][i] = new Bebida("FRESCOLECHE", "20", "DE FRESA (TOP).","bebida", 450, true, 450, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[0][i] = new Bebida("COCA COLA", "21", "SABOR ORIGINAL.","bebida", 1000, true, 1000, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[0][i] = new Bebida();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasBebidas() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[0][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Agua \n 2- Frescoleche \n 3- Coca Cola \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        System.out.println("AJAAAAAAAA "+((100 - contador)+cantidad));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "AGUA";
                id = "19";
                descrip = "AGUA NATURAL, REFRESCANTE.";
                precio = 1000;
                break;
            case 2:
                nombre = "FRECOLECHE";
                id = "20";
                descrip = "DE FRESA (TOP).";
                precio = 450;
                break;
            case 3:
                nombre = "COCA COLA";
                id = "21";
                descrip = "SABOR ORIGINAL.";
                precio = 1000;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto bebida:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto bebida:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto bebida:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto bebida:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[0][i].getID() == null) {
                ZarpeOQue.productos[0][i] = new Bebida(nombre, id, descrip,"bebida", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
