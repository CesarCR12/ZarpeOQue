
package zarpeoque;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public final class BodegaProducto {
    List<Producto> allproductos = new ArrayList<>();
    List<Producto> bodegaCongealdos = new ArrayList<>();
    List<Producto> bodegaBebidas = new ArrayList<>(); 
    List<Producto> bodegaCarnes = new ArrayList<>();
    List<Producto> bodegaEnlatados = new ArrayList<>();
    List<Producto> bodegaFarmaco = new ArrayList<>();
    List<Producto> bodegaLicor = new ArrayList<>();
    List<Producto> bodegaHarina = new ArrayList<>();
    List<Producto> bodegaLegumbre = new ArrayList<>();
    List<Producto> bodegaSnack = new ArrayList<>();
    List<Producto> bodegaLacteo = new ArrayList<>();
    List<Producto> bodegaFrutaverdura = new ArrayList<>(); 
    int cantidad = 0;
    
    public void recorrerListaZarpe() {
        for (int i = 0; i < ZarpeOQue.productos.length; i++) {
            for (int j = 0; j < ZarpeOQue.productos[i].length; j++) {
                Producto producto = ZarpeOQue.productos[i][j];
                if (producto.getCategoria() != null) {
                    switch (producto.getCategoria()) {
                        case "bebida":
                            producto = new Bebida(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "congelado":
                            producto = new Congelado(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "carne":
                            producto = new Carne(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "enlatado":
                            producto = new Enlatado(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "farmaco":
                            producto = new Farmaco(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "harina":
                            producto = new Harina(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "lacteo":
                            producto = new Lacteo(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "fruta/verdura":
                            producto = new Fruta_Verdura(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "legumbre":
                            producto = new Legumbre(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "licor":
                            producto = new Licor(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                        case "snack":
                            producto = new Snack(producto.getNombre(), producto.getID(), producto.getDescripcion(), producto.getCategoria(), producto.getPrecioBruto(), producto.getEstado(), producto.getPrecioNeto(), producto.getCaducidad());
                            break;
                    }

                    // Agregar el producto a la lista 'allproductos'
                    allproductos.add(producto);

                    // Distribuir el producto en la bodega correspondiente
                    switch (producto.getCategoria()) {
                        case "congelado":
                            bodegaCongealdos.add(producto);
                            break;
                        case "carne":
                            bodegaCarnes.add(producto);
                            break;
                        case "enlatado":
                            bodegaEnlatados.add(producto);
                            break;
                        case "farmaco":
                            bodegaFarmaco.add(producto);
                            break;
                        case "licor":
                            bodegaLicor.add(producto);
                            break;
                        case "harina":
                            bodegaHarina.add(producto);
                            break;
                        case "legumbre":
                            bodegaLegumbre.add(producto);
                            break;
                        case "snack":
                            bodegaSnack.add(producto);
                            break;
                        case "lacteo":
                            bodegaLacteo.add(producto);
                            break;
                        case "fruta/verdura":
                            bodegaFrutaverdura.add(producto);
                            break;
                        case "bebidas":
                            bodegaBebidas.add(producto);
                            break;
                    }
                    cantidad++;
                }
            }
        }
    }


    



    public void imprimirProductosPorCategoria(String nombreCategoria) {
        for (Producto producto : allproductos) {
            if (producto.getCategoria() != null && producto.getCategoria().equalsIgnoreCase(nombreCategoria)) {
                System.out.println("Nombre: " + producto.getNombre());
                System.out.println("ID: " + producto.getID());
                System.out.println("Descripción: " + producto.getDescripcion());
                System.out.println("Categoría: " + producto.getCategoria());
                System.out.println("Precio Bruto: " + producto.getPrecioBruto());
                System.out.println("Estado: " + producto.getEstado());
                System.out.println("Precio Neto: " + producto.getPrecioNeto());
                System.out.println("Caducidad: " + producto.getCaducidad());
                System.out.println("----------------------");
            }
        }
    }
   
}