
package zarpeoque;

import javax.swing.SwingUtilities;



public class Bodeguero extends Persona implements GestionBodega{
    final double salarioHora = 17.50;
    
    // Hacer instancia de la bodega para la gestion de la misma
    public static BodegaProducto bodega = new BodegaProducto();
   
    
    // Primero tenemos que ver cuantos productos tenemos en la bodega 
  
  
    public Bodeguero(int cedula, int edad, String nombre, char genero) {
        super(cedula, edad, nombre, genero);
    }
    
    @Override
    public void reestablecerInventario(){
       
    }
    @Override
    public void recibirEntregas(){
        // En este apartado tendremos que manejar el modulo de finanzas para realizar el pago de los productos
        // Tambien se puede anotar en otra tabla las fechas en que se recibe la entrega en forma de registro
    }
    @Override
    public void quitarProductos(){
        // While(productos.getFecha_Expiracion == true){Eliminar el producto de el array con .remove() }
    }
    @Override
     public void verInventario() {
        // Llenar la información de la bodega
        bodega.recorrerListaZarpe();

            SwingUtilities.invokeLater(() -> {
            TablaProducto tablaProducto = new TablaProducto(bodega);
            tablaProducto.setVisible(true);
         });
       
    }

    @Override
    public void pedirEntrega() {
        
    }
      
}
