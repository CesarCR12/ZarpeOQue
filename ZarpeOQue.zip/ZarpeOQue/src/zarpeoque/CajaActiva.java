
package zarpeoque;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import javax.swing.JOptionPane;

public class CajaActiva {
     
    // Esto va permitir manejar las colas mas adelnate 
    private int contadorPreferenciales = 0;
    private int contadorRegular = 0; 
    boolean esPremiun = false;
    private double descuento;
    
    // Crear una cola utilizando LinkedList para la fila de clientes 
    Queue<Cliente> cola = new LinkedList<>();
    private List<Producto> carritoProductos = new ArrayList<>();
    
    
    // Metodos de la cola 
    public boolean esVacia(){
        return cola.peek() == null;
    }
    public Queue<Cliente> obtenerCola() {
        return cola;
    }
    public List<Producto> getCarritoProductos() {
        return carritoProductos;
    }

    // Comienzo de los metodos set y get 
    public void setEsPremiun(boolean esPremiun) {
        this.esPremiun = esPremiun;
    }
    public boolean isEsPremiun() {
        return esPremiun;
    }
    public void getesPremiun(boolean esPremiun){
        this.esPremiun = esPremiun;
    }
    public void setContadorPreferenciales(int contadorPreferenciales) {
        this.contadorPreferenciales = contadorPreferenciales;
    }

    public void setContadorRegular(int contadorRegular) {
        this.contadorRegular = contadorRegular;
    }

    public int getContadorPreferenciales() {
        return contadorPreferenciales;
    }

    public int getContadorRegular() {
        return contadorRegular;
    }
    // Fin de los metodos set y get 
    
    public void Caja_Uno() {
        Cajero cajero_Uno = new Cajero(23,2086,"Pablo Emilio",'M');
     
        cajero_Uno.LlamarUsuario();
        try {
            // Verificar si el usuario al ingresar es premium o posee una cuenta 
            String answer = JOptionPane.showInputDialog(null, "Bienvenido a Super Zarpe!\n¿Posee una cuenta premium? (yes/no)").toUpperCase();

            if (answer.equals("YES")) {
                this.esPremiun = true;
                descuento = 10.5;
                // El cajero de la caja 1 procesa la compra 
                cajero_Uno.procesarCompra();
                // Obtener el precio final de la compra 
                double montoFinal = cajero_Uno.getMontoFinal();
                
                // Aplicar el descuento 
                double montoConDescuento = montoFinal * (1 - descuento / 100.0);
                
                // Establecer el nuevo monto final
                cajero_Uno.setMontoFinal(montoConDescuento); 
                System.out.println(cajero_Uno.Mostrar_CompraFinal());
                
            } else if (answer.equals("NO")) {
                this.esPremiun = false;
                descuento = 0;
                System.out.println(cajero_Uno.Mostrar_CompraFinal());
            } else {
                JOptionPane.showMessageDialog(null, "Respuesta inválida. Por favor, responda 'yes' o 'no'.", "Error", JOptionPane.ERROR_MESSAGE);
               
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public void caja_dos(){
        Cajero caja_dos = new Cajero(1033,22,"Mohamed",'M');
        
        caja_dos.LlamarUsuario();
        try {
            // Verificar si el usuario al ingresar es premium o posee una cuenta 
            String answer = JOptionPane.showInputDialog(null, "Bienvenido a Super Zarpe!\n¿Posee una cuenta premium? (yes/no)").toUpperCase();

            if (answer.equals("YES")) {
                this.esPremiun = true;
                descuento = 10.5;
                // El cajero de la caja 1 procesa la compra 
                caja_dos.procesarCompra();
                // Obtener el precio final de la compra 
                double montoFinal = caja_dos.getMontoFinal();
                
                // Aplicar el descuento 
                double montoConDescuento = montoFinal * (1 - descuento / 100.0);
                
                // Establecer el nuevo monto final
                caja_dos.setMontoFinal(montoConDescuento); 
                System.out.println(caja_dos.Mostrar_CompraFinal());
                
            } else if (answer.equals("NO")) {
                this.esPremiun = false;
                descuento = 0;
                double montoFinal = caja_dos.getMontoFinal();
                caja_dos.setMontoFinal(montoFinal); 
                System.out.println(caja_dos.Mostrar_CompraFinal());
            } else {
                JOptionPane.showMessageDialog(null, "Respuesta inválida. Por favor, responda 'yes' o 'no'.", "Error", JOptionPane.ERROR_MESSAGE);
               
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}