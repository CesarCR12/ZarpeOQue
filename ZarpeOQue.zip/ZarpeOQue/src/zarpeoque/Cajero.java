
package zarpeoque;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Queue;
import javax.swing.JOptionPane;


public class Cajero extends Persona implements GestionCaja{
    final double salarioHora = 13.50;
    double recuentoDeDinero = 0;
    private double montoFinal = 0;
    private boolean disponible = true;

    static CajaActiva cajas = new CajaActiva();
    Queue<Cliente> colaClientes = cajas.obtenerCola();
    
    
    public void setMontoFinal(double montoFinal) {
        this.montoFinal = montoFinal;
    }

    public double getMontoFinal() {
        return montoFinal;
    }
    public boolean isDisponible() {
        return disponible;
    }
    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

 
    public Cajero(int cedula, int edad, String nombre, char genero) {
        super(cedula, edad, nombre, genero);
    }
   
    @Override
    public void LlamarUsuario(){
        if(!cajas.esVacia()){
            colaClientes.poll();
            JOptionPane.showMessageDialog(null,"Cliente al inicio de la fila: " + colaClientes.peek() + " Pasar a caja");
        }else{
            JOptionPane.showMessageDialog(null,"No hay clientes en la fila que atender");
        }
    }
    
   
    @Override
    public double procesarCompra() {
        double totalCompra = 0;

        if (!colaClientes.isEmpty()) {
            Cliente cliente = colaClientes.peek();

            List<Producto> carritoProductos = cliente.getCarrito(); // Obtener el carrito de compras del cliente
            boolean esPremium = cliente instanceof ClientePremium; // Verificar si el cliente es Premium

            for (Producto producto : carritoProductos) {
                totalCompra += producto.getPrecioBruto();
            }

            if (esPremium) {
                totalCompra *= 0.9; 
            }

            montoFinal = totalCompra;
        }

        return montoFinal;
    }   
   @Override
    public void vaciarCaja(double recuentoDeDinero) {
        double dineroRecibido = montoFinal; // Dinero recibido por la compra
        this.recuentoDeDinero += dineroRecibido; // Sumar el dinero al recuento total de la caja

        // Reiniciar el monto final y la disponibilidad de la caja para el siguiente cliente
        montoFinal = 0;
        disponible = true;

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date fechaActual = new Date();

        // Imprimir un mensaje sobre el recuento de dinero y la finalización de la transacción
        String message = "Caja vaciada el " + sdf.format(fechaActual) + "\n";
        message += "Dinero recibido: " + dineroRecibido + "\n";
        message += "Total acumulado en la caja: " + recuentoDeDinero + "\n";
        message += "Gracias por su compra.";

        JOptionPane.showMessageDialog(null, message);
    }
    
   
    @Override
    public String Mostrar_CompraFinal() {
        String message = "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date fechaActual = new Date();

        message += "Fecha de compra: " + sdf.format(fechaActual) + "\n";
        message += "Detalles de la compra:\n";

        if (!colaClientes.isEmpty()) {
            Cliente cliente = colaClientes.peek();
            List<Producto> carritoProductos = cliente.getCarrito(); 

            double totalCompra = 0;

            for (Producto producto : carritoProductos) {
                message += "Producto: " + producto.getNombre() + "\n";
                message += "Descripción: " + producto.getDescripcion() + "\n";
                message += "Precio: " + producto.getPrecioBruto() + "\n\n";

                totalCompra += producto.getPrecioBruto();
            }

            message += "Total de la compra: " + totalCompra + "\n";
        }

        return message;
    }
  
    @Override
    public boolean empezarTurno(){
        
        try {
            // Obtener la fecha y hora actual
            Date fechaActual = new Date();

            // Formatear la hora actual en formato de 24 horas
            SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm");
            String horaActual = formatoHora.format(fechaActual);

            // Comparar con la condición para comenzar el turno a las 8 am
            if (horaActual.equals("08:00")) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            // Manejar excepciones y mostrar mensaje de error
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    @Override
    public boolean terminarTurno() {
        
        try {
            // Obtener la fecha y hora actual
            Date fechaActual = new Date();

            // Formatear la hora actual en formato de 24 horas
            SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm");
            String horaActual = formatoHora.format(fechaActual);

            // Comparar con las condiciones establecidas
           
            if (horaActual.equals("20:00")) {
                JOptionPane.showMessageDialog(null, "¡Fin del turno a las 8 pm!");
                return true;
            } else {
                // Si no es ninguna de las condiciones anteriores, el turno sigue
                return false;
            }
        } catch (Exception e) {
            // Manejar excepciones y mostrar mensaje de error
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    @Override
    public boolean tomarAlmuerzo() {
        
        try {
            // Obtener la fecha y hora actual
            Date fechaActual = new Date();

            // Formatear la hora actual en formato de 24 horas
            SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm");
            String horaActual = formatoHora.format(fechaActual);

            // Comparar con las condiciones para tomar almuerzo
            if (horaActual.equals("12:00")) {
                JOptionPane.showMessageDialog(null, "Es hora de almuerzo. ¡Caja cerrada!");
                return true;
            } else if (horaActual.equals("12:40")) {
                JOptionPane.showMessageDialog(null, "¡Hora de almuerzo concluida!");
                return false;
            } else {
                return false;
            }
        } catch (Exception e) {
            // Manejar excepciones y mostrar mensaje de error
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }   
 
} 

