
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Carne extends Producto{
   

    public Carne(String nombre, String ID, String descripcion, String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Carne() {
    }//final construcutor vacio

    
    public static void instanciarCarnes(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[10][i] = new Carne("Filete de salmón".toUpperCase(), "22", "Filete de salmón fresco, rico en ácidos grasos omega-3.".toUpperCase(),"carne", 3500, true, 3500, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[10][i] = new Carne("pechuga de pollo".toUpperCase(), "23", "pechuga de pollo sin piel, magra y versátil.".toUpperCase(),"carne", 2000, true, 2000, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[10][i] = new Carne("Carne molida de res".toUpperCase(), "24", "Carne molida de res, perfecta para preparar hamburguesas y guisos.".toUpperCase(),"carne", 2500, true, 2500, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[10][i] = new Carne();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasCarnes() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[10][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Filete de Salmón \n 2- Pechuga de pollo \n 3- Carne Molida de Res \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "Filete de Salmón".toUpperCase();
                id = "22";
                descrip = "Filete de salmón fresco, rico en ácidos grasos omega-3.".toUpperCase();
                precio = 3500;
                break;
            case 2:
                nombre = "Pechuga de Pollo".toUpperCase();
                id = "23";
                descrip = " Pechuga de pollo sin piel, magra y versátil.".toUpperCase();
                precio = 2000;
                break;
            case 3:
                nombre = "Carne Molida de Res".toUpperCase();
                id = "24";
                descrip = "Carne molida de res, perfecta para preparar hamburguesas y guisos.".toUpperCase();
                precio = 2500;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto Carne:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto Carne:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto Carne:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto Carne:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[10][i].getID() == null) {
                ZarpeOQue.productos[10][i] = new Carne(nombre, id, descrip,"carne", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
