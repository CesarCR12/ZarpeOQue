
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Carne extends Producto{
   

    public Carne(String nombre, String ID, int cantidad,String descripcion, String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, cantidad,descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Carne() {
    }//final construcutor vacio

    
    public static void instanciarCarnes(){
        ListaProductos.cargarDatosCarne();
        for (int i = 3; i < 6; i++) {
            ZarpeOQue.productos[10][i] = new Carne();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasCarnes() {
        int contador = 0;
        //eliminamos los espacios de nueva mercancia en caso de que se acaben
        for (int i = 3; i < 6; i++) {
            if (ZarpeOQue.productos[10][i].getCantidad()<= 0) {
                ZarpeOQue.productos[10][i] = new Carne();
            }//final if        
        }//final for
        
        //verificamos los espacios disponibles para nueva mercacia
        for (int i = 0; i < ZarpeOQue.productos[10].length; i++) {
            if (ZarpeOQue.productos[10][i].getID() == null) {
                contador++;
            }
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Filete de Salmón \n 2- Pechuga de pollo \n 3- Carne Molida de Res \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        if (categoria == 4) {
            //si los espacios para nueva mercancia estan en uso no dejara agregar otros
            if (contador <= 0) {
                JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario para nueva mercancía.");
                return;
            }
        }//final if

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog
        ("Cuantos productos quiere agregar?"));

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        int cantidadFinal = cantidad;
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                cantidadFinal += ZarpeOQue.productos[10][0].getCantidad();
                ZarpeOQue.productos[10][0].setCaducidad(LocalDate.now().plusDays(2));
                ZarpeOQue.productos[10][0].setCantidad(cantidadFinal);
                id = ZarpeOQue.productos[10][0].getID();
                ListaProductos.actualizarCantidad(id, cantidadFinal);
                ListaProductos.actualizarCaducidad(id, LocalDate.now().plusDays(2));
                break;
            case 2:
                cantidadFinal += ZarpeOQue.productos[10][1].getCantidad();
                ZarpeOQue.productos[10][1].setCaducidad(LocalDate.now().plusDays(2));
                ZarpeOQue.productos[10][1].setCantidad(cantidadFinal);
                id = ZarpeOQue.productos[10][1].getID();
                ListaProductos.actualizarCantidad(id, cantidadFinal);
                ListaProductos.actualizarCaducidad(id, LocalDate.now().plusDays(2));
                break;
            case 3:
                cantidadFinal += ZarpeOQue.productos[10][2].getCantidad();
                ZarpeOQue.productos[10][2].setCaducidad(LocalDate.now().plusDays(2));
                ZarpeOQue.productos[10][2].setCantidad(cantidadFinal);
                id = ZarpeOQue.productos[10][2].getID();
                ListaProductos.actualizarCantidad(id, cantidadFinal);
                ListaProductos.actualizarCaducidad(id, LocalDate.now().plusDays(2));
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio:"));
                for (int i = 0; i < ZarpeOQue.productos[10].length; i++) {
                    if (ZarpeOQue.productos[10][i].getID() == null) {
                        ZarpeOQue.productos[10][i] = new Carne(nombre, id, cantidad, descrip,"carne", precio, true, precio, LocalDate.now().plusDays(2));
                        id = ZarpeOQue.productos[10][i].getID();
                        ListaProductos.actualizarCantidad(id, cantidadFinal);
                        ListaProductos.actualizarCaducidad(id, LocalDate.now().plusDays(2));
                        break;
                    }
                }
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }
    }
    
}//final clase
