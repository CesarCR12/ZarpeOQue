
package zarpeoque;
import java.util.List;
import java.util.ArrayList;

public class Cliente {
    
    
    private String id;
    private String nombre;
    public List<Producto> carrito;
    private String metodoPago;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public Cliente(String id, String metodoPago, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.metodoPago = metodoPago;
        this.carrito = new ArrayList<Producto>();
    }//final constructor lleno
    
    public Cliente(){}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<Producto> getCarrito() {
        return carrito;
    }

    public void setCarrito(List<Producto> carrito) {
        this.carrito = carrito;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }
    
    
    
}//final clase
