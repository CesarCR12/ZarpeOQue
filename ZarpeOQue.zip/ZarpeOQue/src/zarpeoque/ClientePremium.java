
package zarpeoque;
import java.util.*;
import javax.swing.JOptionPane;

public class ClientePremium extends Cliente {
    Random random = new Random();
    Snack producto1 = new Snack();

    public ClientePremium(String id, String metodoPago, String nombre) {
        super(id, metodoPago, nombre);
    }

    public ClientePremium() {
        this.carrito = new ArrayList<Producto>();
    }  

    public void agregarCompra(int variable1){
            int variable2 = random.nextInt(0, 6);
            int variable3 = random.nextInt(0, 4)+1;
            Producto producto = ZarpeOQue.productos[variable1][variable2];
            List<Producto> carrito = getCarrito();
            if (producto != null && producto.getEstado()!=false) {
                variable2 = random.nextInt(0, 3);
                producto = ZarpeOQue.productos[variable1][variable2];
                String id = producto.getID();
                if (producto.cantidadDisponible(id)-variable3 >=0) {
                    for (int i = 0; i < variable3; i++) {
                        carrito.add(producto);
                    }//final for
                    int cantidad = producto.getCantidad();
                    producto.setCantidad(cantidad-variable3);
                }//final if
            }//final if
    }//Final metodo agregarCompra

    public void finalizarCompra(List<Producto> carrito, ClientePremium cliente, double descuento) {
        double ventas = 0;
        for (int i = 0; i < carrito.size(); i++) {
            ventas += carrito.get(i).getPrecioNeto();
        }//final for
        ventas = ventas - descuento;
        ZarpeOQue.reporte.setVentas(ventas);
        JOptionPane.showMessageDialog(null, "Muchas gracias por comprar en Zarpe O Que!\n Vuelva pronto!");
    }//final metodo finalizarCompra
    
    public void cancelarCompra(List<Producto> carrito){
        for (int i = 0; i < carrito.size();) {
            String ID = carrito.get(i).getID();
            int j = producto1.buscarProductoFila(ID);
            int k = producto1.buscarProductoColumna(ID);
            if (ID.equals(ZarpeOQue.productos[j][k].getID())) {
                int cantidad = ZarpeOQue.productos[j][k].getCantidad() + 1;
                ZarpeOQue.productos[j][k].setCantidad(cantidad);
                ListaProductos.actualizarCantidad(ID, cantidad);
                System.out.println(cantidad);
                carrito.remove(carrito.get(i));
                System.out.println("Eliminado");
            }//final if
        }//Final for
    }//Final metodo cancelarCompra


}
    

