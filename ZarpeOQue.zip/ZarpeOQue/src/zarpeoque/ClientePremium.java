
package zarpeoque;
import java.util.*;

public class ClientePremium extends Cliente {
    
    
    private double descuento;
    private int Puntos_Acumulados;

    public ClientePremium(String id, String metodoPago, String nombre) {
        super(id, metodoPago, nombre);
    }

    public double getDescuento() {
        return descuento;
    }

    public int getPuntos_Acumulados() {
        return Puntos_Acumulados;
    }
    

    public void actualizarInfo(String ID) {
        this.setId(ID);
    }

    public void canjearPuntos() {
        if (Puntos_Acumulados >= 100) {
            int canje = Puntos_Acumulados / 100;
            Puntos_Acumulados -= canje * 100;
            System.out.println("Canje de puntos exitoso. Se aplicó un descuento de " + canje * 10 + "%.");
        } else {
            System.out.println("No tienes suficientes puntos para canjear.");
        }
    }

    public void aplicarDescuento() {
        System.out.println("Se aplicó un descuento del " + descuento * 100 + "% en la compra.");
    }

    public boolean realizarCompra(Compra compra) {
        this.historialCompras.add(compra);
            System.out.println("Compra realizada: " + compra);
            return true;
    }

    public void historialDeCompras() {
        System.out.println("Historial de compras de " + this.getId() + ":");
        for (Compra compra : this.historialCompras) {
            System.out.println(compra);
        }
    }

    public void metodosDePago() {
        System.out.println("Métodos de pago de " + this.getId() + ": "+ this.getMetodoPago());
    }
        
    public void solicitarReembolso(Compra compra) {
        List<Compra> nuevoHistorial = new ArrayList<>();

        boolean compraEncontrada = false;

        for (Compra c : historialCompras) {
            if (c.equals(compra)) {
                compraEncontrada = true;
            } else {
                nuevoHistorial.add(c);
            }
        }

        if (compraEncontrada) {
            historialCompras = nuevoHistorial;
            System.out.println("Reembolso solicitado y procesado para: " + compra);
        } else {
            System.out.println("La compra no se encuentra en el historial.");
        }
    }
}
    

