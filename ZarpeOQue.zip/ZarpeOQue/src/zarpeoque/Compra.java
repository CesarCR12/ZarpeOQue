
package zarpeoque;

public class Compra {
    private String producto;
    private double monto;
    
    public Compra(String producto, double monto) {
        this.producto = producto;
        this.monto = monto;
    }

    @Override
    public String toString() {
        return "Producto: " + producto + ", Monto: " + monto;
    }

    public String getProducto() {
        return producto;
    }

    public double getMonto() {
        return monto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }
    
}
