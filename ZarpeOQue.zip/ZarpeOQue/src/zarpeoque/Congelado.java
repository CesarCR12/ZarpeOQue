
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;


public class Congelado extends Producto{
    // array que contiene los congelados y luego sera movido al array original que contiene todo los productos 


    public Congelado(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Congelado() {
    }//final construcutor vacio

    
    public static void instanciarCongelados(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[9][i] = new Congelado("PIZZA ", "10", "PIZZA DE JAMON Y QUESO.","congelado", 2800, true, 2800, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[9][i] = new Congelado("NUGGETS", "11", "NUGGETS DE POLLO CONGELADOS.","congelado", 1500, true, 1500, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[9][i] = new Congelado("HELADO", "12", "HELADO DE CHOCOLATE CON GALLETA.","congelado", 2000, true, 2000, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[9][i] = new Congelado();
        }    
    }//final metodo instanciarHarinas
   
    public static void pedirMasCongelados() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[9][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Pizza \n 2- Nuggets \n 3- Helado \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        System.out.println("AJAAAAAAAA "+((100 - contador)+cantidad));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "PIZZA";
                id = "10";
                descrip = "QUESO DE ALTA CALIDAD, SUAVE Y DELICIOSO.";
                precio = 2800;
                break;
            case 2:
                nombre = "NUGGETS";
                id = "11";
                descrip = "NUGGETS DE POLLO CONGELADOS.";
                precio = 1500;
                break;
            case 3:
                nombre = "HELADO";
                id = "12";
                descrip = "HELADO DE CHOCOLATE CON GALLETA.";
                precio = 2000;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto congelado:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto congelado:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto congelado:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto congelado:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[9][i].getID() == null) {
                ZarpeOQue.productos[9][i] = new Congelado(nombre, id, descrip,"congelado", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
