
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;


public class Enlatado extends Producto{


    public Enlatado(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Enlatado() {
    }//final construcutor vacio

    
    public static void instanciarEnlatados(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[8][i] = new Enlatado("ATUN ", "13", "ATUN ENLATADO EN ACEITE.","enlatado", 1300, true, 1300, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[8][i] = new Enlatado("MAIZ", "14", "MAIZ DULCE ENLATADO.","enlatado", 900, true, 900, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[8][i] = new Enlatado("SOPA DE TOMATE", "15", "SOPA DE TOMATE LISTA PARA CALENTAR Y SERVIR.","enlatado", 1200, true, 1200, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[8][i] = new Enlatado();
        }    
    }//final metodo instanciarHarinas
     
    public static void pedirMasEnlatados() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[8][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Atún \n 2- Maíz \n 3- Sopa de Tomate \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        System.out.println("AJAAAAAAAA "+((100 - contador)+cantidad));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "ATUN";
                id = "13";
                descrip = "ATUN ENLATADO EN ACEITE.";
                precio = 1300;
                break;
            case 2:
                nombre = "MAIZ";
                id = "14";
                descrip = "MAIZ DULCE ENLATADO.";
                precio = 900;
                break;
            case 3:
                nombre = "SOPA DE TOMATE";
                id = "15";
                descrip = "SOPA DE TOMATE LISTA PARA CALENTAR Y SERVIR.";
                precio = 1200;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto enlatado:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto enlatado:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto enlatado:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto enlatado:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[8][i].getID() == null) {
                ZarpeOQue.productos[8][i] = new Enlatado(nombre, id, descrip,"enlatado", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
