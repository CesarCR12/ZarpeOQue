
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;

public class Farmaco extends Producto{

    public Farmaco(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Farmaco() {
    }//final construcutor vacio

    
    public static void instanciarFarmacos(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[7][i] = new Farmaco("Ibuprofeno".toUpperCase(), "25", "Ibuprofeno, analgésico y antiinflamatorio.".toUpperCase(),"farmaco", 1200, true, 1200, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[7][i] = new Farmaco("vitaminas".toUpperCase(), "26", "Suplemento de vitaminas y minerales para la salud general.".toUpperCase(),"farmaco", 1800, true, 1800, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[7][i] = new Farmaco("Farmaco molida de res".toUpperCase(), "27", "Jarabe para la tos, alivio rápido y efectivo.".toUpperCase(),"farmaco", 800, true, 800, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[7][i] = new Farmaco();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasFarmacos() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[7][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Ibuprofeno \n 2- Vitaminas \n 3- Jarabe para la Tos \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "Ibuprofeno".toUpperCase();
                id = "25";
                descrip = "Ibuprofeno, analgésico y antiinflamatorio.".toUpperCase();
                precio = 1200;
                break;
            case 2:
                nombre = "vitaminas".toUpperCase();
                id = "26";
                descrip = "Suplemento de vitaminas y minerales para la salud general.".toUpperCase();
                precio = 1800;
                break;
            case 3:
                nombre = "Jarabe para la Tos".toUpperCase();
                id = "27";
                descrip = "Jarabe para la tos, alivio rápido y efectivo.".toUpperCase();
                precio = 800;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto Farmaco:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto Farmaco:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto Farmaco:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto Farmaco:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[7][i].getID() == null) {
                ZarpeOQue.productos[7][i] = new Farmaco(nombre, id, descrip,"farmaco", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
