
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;

public class Fruta_Verdura extends Producto{

    public Fruta_Verdura(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Fruta_Verdura() {
    }//final construcutor vacio

    
    public static void instanciarFruta_Verduras(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[6][i] = new Fruta_Verdura("MANZANAS ", "16", "MANZANAS FRESCAS Y JUGOSAS.","fruta/verdura", 400, true, 400, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[6][i] = new Fruta_Verdura("ZANAHORIAS", "17", "ZANAHORIAS FRESCAS IDEALES PARA ENSALADAS.","fruta/verdura", 300, true, 300, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[6][i] = new Fruta_Verdura("MANGO", "18", "MANGO MADURO Y DULCE.","fruta/verdura", 800, true, 800, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[6][i] = new Fruta_Verdura();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasFruta_Verduras() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[6][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Manzanas \n 2- Zanahorias \n 3- Mango \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        System.out.println("AJAAAAAAAA "+((100 - contador)+cantidad));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "MANZANAS";
                id = "16";
                descrip = "MANZANAS FRESCAS Y JUGOSAS.";
                precio = 400;
                break;
            case 2:
                nombre = "ZANAHORIAS";
                id = "17";
                descrip = "ZANAHORIAS FRESCAS IDEALES PARA ENSALADAS.";
                precio = 300;
                break;
            case 3:
                nombre = "SOPA DE TOMATE";
                id = "18";
                descrip = "SOPA DE TOMATE LISTA PARA CALENTAR Y SERVIR.";
                precio = 800;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto Fruta-Verdura:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto Fruta-Verdura:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto Fruta-Verdura:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto Fruta-Verdura:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[6][i].getID() == null) {
                ZarpeOQue.productos[6][i] = new Fruta_Verdura(nombre, id, descrip,"fruta/verdura", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
