
package zarpeoque;

import java.time.LocalDate;


public class Ganancias {

private double ganancia, gastos, ventas;
private LocalDate fecha;
static Snack producto1 = new Snack();

    public Ganancias() {
        ganancia = 0;
        gastos = 0;
        ventas = 0;
        setFecha(LocalDate.now());
    }//final constructor vacío
    
    public double getGanancia() {
        return ganancia;
    }

    public void setGanancia(double aGanancia) {
        ganancia = aGanancia;
    }

    public double getGastos() {
        return gastos;
    }

    public void setGastos(double aGastos) {
        gastos += aGastos;
    }

    public double getVentas() {
        return ventas;
    }

    public void setVentas(double aVentas) {
        ventas += aVentas;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate aFecha) {
        fecha = aFecha;
    }

    public static void calcularGanancias(){
        double ganancias = ZarpeOQue.reporte.getVentas()-ZarpeOQue.reporte.getGastos();
        ZarpeOQue.reporte.setGanancia(ganancias);
    }//Final metodo calcularGanancias
    
    public static void calcularGastos(String id, int cantidad){
        int x = producto1.buscarProductoFila(id);
        int y = producto1.buscarProductoColumna(id);
        Producto producto = ZarpeOQue.productos[x][y];
        double compra = producto.getPrecioBruto() * 0.30;
        compra = producto.getPrecioBruto() - compra;
        compra = compra * cantidad;
        ZarpeOQue.reporte.setGastos(compra);
    }//final del metodo calcularGastos
    
    public static void subirReporteBD(){
        Ganancias.calcularGanancias();
        double ganancias = ZarpeOQue.reporte.getGanancia();
        double ventas = ZarpeOQue.reporte.getVentas();
        double gastos = ZarpeOQue.reporte.getGastos();
        LocalDate fecha = ZarpeOQue.reporte.getFecha();
        SimularContadorGanancias.gananciaAgregar(ganancias, gastos, ventas, fecha);
    }//final metodo subirReporteBD
}//Final de la clase
