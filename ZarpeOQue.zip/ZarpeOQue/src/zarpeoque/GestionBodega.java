
package zarpeoque;

public interface GestionBodega {
    // metodos que realiza un empleado de bodega 
    void verInventario();
    void quitarProductos();
    void reestablecerInventario();
    void recibirEntregas();
    void pedirEntrega();
   
   
    
}
