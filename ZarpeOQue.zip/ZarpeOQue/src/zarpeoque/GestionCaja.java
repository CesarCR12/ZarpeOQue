
package zarpeoque;

public interface GestionCaja {
    
    // Metodos de procesos
    double procesarCompra();
    void LlamarUsuario();

    /**
     *
     * @param recuentoDeDinero
     */
    void vaciarCaja(double recuentoDeDinero);
    String Mostrar_CompraFinal();
    
    // Metodos de turno
    boolean empezarTurno();
    boolean terminarTurno();
    boolean tomarAlmuerzo();
}
