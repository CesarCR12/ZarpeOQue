
package zarpeoque;

public interface GestionVenta {
    
}
