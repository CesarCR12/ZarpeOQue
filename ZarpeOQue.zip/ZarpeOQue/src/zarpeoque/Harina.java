
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;

public class Harina extends Producto{

    public Harina(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Harina() {
    }//final construcutor vacio

    
    public static void instanciarHarinas(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[5][i] = new Harina("HARINA INTEGRAL", "4", "HARINA INTEGRAL, IDEAL PARA PREPARAR PANES Y MASAS SALUDABLES.","harina", 900, true, 900, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[5][i] = new Harina("HARINA DE MAÍZ", "5", "HARINA DE MAÍZ FINA, PERFECTA PARA HACER AREPAS Y TORTILLAS.","harina", 600, true, 600, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[5][i] = new Harina("HARINA DE ALMENDRAS", "6", "HARINA DE ALMENDRAS, SIN GLUTEN, EXCELENTE PARA REPOSTERÍA.","harina", 3500, true, 3500, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[5][i] = new Harina();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasHarinas() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[5][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Harina Integral \n 2- Harina de Maíz \n 3- Harina de Almendras \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        System.out.println("AJAAAAAAAA "+((100 - contador)+cantidad));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "HARINA INTEGRAL";
                id = "4";
                descrip = "HARINA INTEGRAL, IDEAL PARA PREPARAR PANES Y MASAS SALUDABLES.";
                precio = 900;
                break;
            case 2:
                nombre = "HARINA DE MAÍZ";
                id = "5";
                descrip = "HARINA DE MAÍZ FINA, PERFECTA PARA HACER AREPAS Y TORTILLAS.";
                precio = 600;
                break;
            case 3:
                nombre = "HARINA DE ALMENDRAS";
                id = "6";
                descrip = "HARINA DE ALMENDRAS, SIN GLUTEN, EXCELENTE PARA REPOSTERÍA.";
                precio = 3500;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto de harina:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto de harina:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto de harina:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto de harina:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[5][i].getID() == null) {
                ZarpeOQue.productos[5][i] = new Harina(nombre, id, descrip,"harina", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
