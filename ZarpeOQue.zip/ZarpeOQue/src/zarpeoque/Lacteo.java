
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;

public class Lacteo extends Producto{

    public Lacteo(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Lacteo() {
    }//final construcutor vacio

    
    public static void instanciarLacteos(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[4][i] = new Lacteo("QUESO", "8", "QUESO DE ALTA CALIDAD, SUAVE Y DELICIOSO","lacteo", 2500, true, 2500, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[4][i] = new Lacteo("YOGURT", "9", "YOGURT NATURAL, BAJO EN GRASAS.","lacteo", 1200, true, 1200, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[4][i] = new Lacteo("LECHE", "10", "LECHE FRESCA Y ORGANICA.","lacteo", 1800, true, 1800, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[4][i] = new Lacteo();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasLacteos() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[4][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Queso \n 2- Yogurt \n 3- Leche \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        System.out.println("AJAAAAAAAA "+((100 - contador)+cantidad));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "QUESO";
                id = "7";
                descrip = "QUESO DE ALTA CALIDAD, SUAVE Y DELICIOSO.";
                precio = 2500;
                break;
            case 2:
                nombre = "YOGURT";
                id = "8";
                descrip = "YOGURT NATURAL, BAJO EN GRASAS.";
                precio = 1200;
                break;
            case 3:
                nombre = "LECHE";
                id = "9";
                descrip = "LECHE FRESCA Y ORGANICA.";
                precio = 1800;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto lacteo:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto lacteo:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto lacteo:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto lacteo:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[4][i].getID() == null) {
                ZarpeOQue.productos[4][i] = new Lacteo(nombre, id, descrip,"lacteo", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
