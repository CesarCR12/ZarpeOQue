
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;

public class Legumbre extends Producto{

    public Legumbre(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Legumbre() {
    }//final construcutor vacio

    
    public static void instanciarLegumbres(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[3][i] = new Legumbre("Lentejas".toUpperCase(), "31", "Lentejas secas, rica en vitaminas.".toUpperCase(),"legumbre", 600, true, 600, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[3][i] = new Legumbre("Garbanzos".toUpperCase(), "32", "Garbanzos secos, ricos en minerales.".toUpperCase(),"legumbre", 500, true, 500, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[3][i] = new Legumbre("Frijoles".toUpperCase(), "33", "Frijoles rojos secos.".toUpperCase(),"legumbre", 700, true, 700, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[3][i] = new Legumbre();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasLegumbres() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[3][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Lentejas \n 2- Garbanzos \n 3- Frijoles \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "Lentejas".toUpperCase();
                id = "31";
                descrip = "Lentejas secas, rica en vitaminas.".toUpperCase();
                precio = 600;
                break;
            case 2:
                nombre = "Garbanzos".toUpperCase();
                id = "32";
                descrip = "Garbanzos secos, ricos en minerales.".toUpperCase();
                precio = 500;
                break;
            case 3:
                nombre = "Frijoles".toUpperCase();
                id = "33";
                descrip = "Frijoles rojos secos.".toUpperCase();
                precio = 700;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto Legumbre:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto Legumbre:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto Legumbre:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto Legumbre:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[3][i].getID() == null) {
                ZarpeOQue.productos[3][i] = new Legumbre(nombre, id, descrip,"legumbre", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
