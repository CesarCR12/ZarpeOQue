
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;

public class Licor extends Producto{

    public Licor(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Licor() {
    }//final construcutor vacio

    
    public static void instanciarLicors(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[2][i] = new Licor("Cacique".toUpperCase(), "28", "Guaro Cacique.".toUpperCase(),"licor", 5600, true, 5600, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[2][i] = new Licor("Vino Tinto".toUpperCase(), "29", "Vino Tinto reserva, cosecha seleccionada.".toUpperCase(),"licor", 4800, true, 4800, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[2][i] = new Licor("Whisky Escocés".toUpperCase(), "30", "Whisky Escocés de malta, envejecido con notas ahumadas.".toUpperCase(),"licor", 7500, true, 7500, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[2][i] = new Licor();
        }    
    }//final metodo instanciarHarinas
    
    public static void pedirMasLicors() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[2][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Cacique \n 2- Vino Tinto \n 3- Whisky Escocés \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "Cacique".toUpperCase();
                id = "28";
                descrip = "Guaro Cacique.".toUpperCase();
                precio = 5600;
                break;
            case 2:
                nombre = "Vino Tinto".toUpperCase();
                id = "29";
                descrip = "Vino Tinto reserva, cosecha seleccionada.".toUpperCase();
                precio = 4800;
                break;
            case 3:
                nombre = "Whisky Escocés".toUpperCase();
                id = "30";
                descrip = "Whisky Escocés de malta, envejecido con notas ahumadas.".toUpperCase();
                precio = 7500;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto Licor:").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto Licor:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del producto Licor:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del producto Licor:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[2][i].getID() == null) {
                ZarpeOQue.productos[2][i] = new Licor(nombre, id, descrip,"licor", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }

    
    
}//final clase
