/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package zarpeoque;

import Enlace.Enlace;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jonathan
 */
public class ListaProductos extends javax.swing.JFrame {
    static Enlace conexion = new Enlace();
    static Connection conectar = conexion.getConexion();
    static DefaultTableModel model;
    static PreparedStatement pst;
    static ResultSet rs;

    public ListaProductos() {
        initComponents();
        setLocationRelativeTo(null);
        recuperar();
    }

    void recuperar(){
    String consultar = "select * from producto";
    //String nombre = nam

    try {
        conectar = conexion.getConexion();
        pst = conectar.prepareStatement(consultar);
        rs = pst.executeQuery(consultar);
        Object[] producto = new Object[9];
        model = (DefaultTableModel) resultados.getModel();
        while (rs.next()) {                
            producto[0] = rs.getInt("id");
            producto[1] = rs.getString("nombre");
            producto[2] = rs.getInt("cantidad");
            producto[3] = rs.getString("descripcion");
            producto[4] = rs.getDouble("precioNeto");
            producto[5] = rs.getDouble("precioBruto");
            producto[6] = rs.getString("categoria");
            producto[7] = rs.getBoolean("estado");
            producto[8] = rs.getDate("caducidad");
            

            model.addRow(producto);
        }//final while
        resultados.setModel(model);

    }//final try
    catch (Exception e) {
        System.out.println("Error recuperando información: "+e.getMessage());
    }//final catch 
    finally {
        
        cerrarRecursos();
    }//final finally
}//final metodo recuperar
        
    public static void agregar(String id, String nombre, int cantidad, String descripcion, String categoria, double precioNeto, double precioBruto,  boolean estado, LocalDate caducidad){


        try {
            if (nombre.equals("")) {

                JOptionPane.showMessageDialog(null, "Debes llenar todos los espacios.");
                
            }

            else{

                int estadoInt = estado ? 1 : 0;  // Si estado es true, estadoInt será 1; de lo contrario, será 0
                if (caducidad != null) {
                    String consultar = "insert into producto("
                    + "id, nombre, cantidad, descripcion, categoria, precioNeto, precioBruto, estado, caducidad)"
                    +"values('"+id+"','"+nombre+"','"+cantidad+"','"+descripcion+"','"+categoria+"','"+precioNeto+"','"+precioBruto+"','"+estadoInt+"','"+caducidad+"')";


                conectar = conexion.getConexion();
                pst = conectar.prepareStatement(consultar);
                pst.executeUpdate(consultar);
                }



                JOptionPane.showMessageDialog(null, "Productos agregados exitosamente.");

            }
        }
        catch (Exception e){
            System.out.println("Error while adding data: "+ e.getMessage());
        }
        finally {
            
            cerrarRecursos();
        }
    }//final add
        
        
    void limpiarTabla(){
        for (int i = 0; i < resultados.getRowCount(); i++) {
            model.removeRow(i);
            i--;
        }//final for
    }//final metodo limpiarTabla
    
    public static void cerrarRecursos(){
            if(rs != null)
            {
                try
                {
                    rs.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
            //Vamos a limpiar la memoria destinada para la consulta
            if(pst != null)
            {
                try
                {
                    pst.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
            //Vamos a cerrar la conexión
            if(conectar != null)
            {
                try
                {
                    conectar.close();
                }
                catch(SQLException error)
                {
                    error.printStackTrace();
                }
            }
    }//final metodo cerrarRecursos
    
    public static void actualizarCantidad(String id, int cantidad) {
        try {

            String actualizarCantidad = "update producto set cantidad = ? where id = ?";

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setInt(1, cantidad);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar la cantidad: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
        
    }//final metodo actualizarCantidad
    
    public static void actualizarEstado(String id, boolean estado){
        try {

            String actualizarCantidad = "update producto set estado = ? where id = ?";

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setBoolean(1, estado);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar el estado: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
    }//final metodo actualizarEstado
    
    public static void actualizarPrecioNeto(String id, double precio){
        try {

            String actualizarCantidad = "update producto set precioNeto = ? where id = ?";

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setDouble(1, precio);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar el precio: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
    }//final metodo actualizarPrecioNeto
    
    public static void actualizarPrecioBruto(String id, double precio){
        try {

            String actualizarCantidad = "update producto set precioBruto = ? where id = ?";

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setDouble(1, precio);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar el precio: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
    }//final metodo actualizarPrecioBruto
    
    public static void actualizarCaducidad(String id, LocalDate caducidad){
        try {

            String actualizarCantidad = "update producto set caducidad = ? where id = ?";
            
            //este pasa de un LocalDate a un Date
            Date fechaCaducidad = Date.valueOf(caducidad);

            // Establecer la conexión y preparar la declaración
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(actualizarCantidad);

            // Establecer los parámetros en la sentencia SQL
            pst.setDate(1, fechaCaducidad);
            pst.setString(2, id);

            pst.executeUpdate();
        }
        catch (SQLException e) {
            System.out.println("Error al actualizar la caducidad: " + e.getMessage());
        } finally {
            // Cerrar recursos
            cerrarRecursos();
        }
    }//final metodo actualizarCaducidad
    
    public static void limpiarMatriz(Producto[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = null;
            }
        }
    }
    
    public static void cargarDatosSnack() {
        String consulta = "select * from producto WHERE categoria = 'snack'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[1].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[1][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[1][i] = new Snack(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosBebidas() {
        String consulta = "select * from producto WHERE categoria = 'bebida'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[0].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[0][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[0][i] = new Snack(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosCarne() {
        String consulta = "select * from producto WHERE categoria = 'carne'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[10].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[10][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[10][i] = new Carne(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosCongelados() {
        String consulta = "select * from producto WHERE categoria = 'congelado'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[9].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[9][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[9][i] = new Congelado(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosEnlatados() {
        String consulta = "select * from producto WHERE categoria = 'enlatado'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[8].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[8][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[8][i] = new Enlatado(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosFarmaco() {
        String consulta = "select * from producto WHERE categoria = 'farmaco'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[7].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[7][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[7][i] = new Farmaco(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosFrutaVerdura() {
        String consulta = "select * from producto WHERE categoria = 'fruta/verdura'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[6].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[6][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[6][i] = new Fruta_Verdura(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosHarina() {
        String consulta = "select * from producto WHERE categoria = 'harina'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[5].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[5][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[5][i] = new Harina(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosLacteo() {
        String consulta = "select * from producto WHERE categoria = 'lacteo'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[4].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[4][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[4][i] = new Lacteo(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosLegumbre() {
        String consulta = "select * from producto WHERE categoria = 'legumbre'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[3].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[3][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[3][i] = new Legumbre(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    public static void cargarDatosLicor() {
        String consulta = "select * from producto WHERE categoria = 'licor'";
        int contador = 0;
        try {
            conectar = conexion.getConexion();
            PreparedStatement pst = conectar.prepareStatement(consulta);
            ResultSet rs = pst.executeQuery();

            // Recorrer el resultado y asignar valores a la matriz
            while (rs.next()) {
                String id = rs.getString("id");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                String descripcion = rs.getString("descripcion");
                double precioBruto = rs.getDouble("precioBruto");
                boolean estado = rs.getBoolean("estado");
                double precioNeto = rs.getDouble("precioNeto");
                LocalDate caducidad = rs.getDate("caducidad").toLocalDate();

                // Encuentra una posición en la matriz para este producto
                for (int i = 0; i < ZarpeOQue.productos[2].length; i++) {
                    contador=i;
                    
                    if (ZarpeOQue.productos[2][i] == null) {
                        System.out.println(nombre);
                        
                        ZarpeOQue.productos[2][i] = new Licor(nombre, id, cantidad, descripcion, "snack", precioBruto, estado, precioNeto, caducidad);
                        break;
                    }
                        

                }
            }
            System.out.println(contador);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//final cargarDatos
    
    
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        resultados = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        resultados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "nombre", "cantidad", "descripcion", "precioNeto", "precioBruto", "categoria", "estado", "caducidad"
            }
        ));
        jScrollPane1.setViewportView(resultados);

        jLabel1.setFont(new java.awt.Font("SansSerif", 0, 36)); // NOI18N
        jLabel1.setText("Lista de Productos");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(347, 347, 347)
                .addComponent(jLabel1)
                .addContainerGap(347, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 119, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListaProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable resultados;
    // End of variables declaration//GEN-END:variables
}
