/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zarpeoque;

/**
 *
 * @author franv
 */
import javax.swing.JOptionPane;

public class Login {
    private static final String USERNAME = "KanyeWest";
    private static final String PASSWORD = "1234";
    private static final int MAX_ATTEMPTS = 3;

    public static void login() {
        int attempts = 0;

        while (attempts < MAX_ATTEMPTS) {
            String usernameInput = JOptionPane.showInputDialog("Ingrese su nombre de usuario:");
            String passwordInput = JOptionPane.showInputDialog("Ingrese su contraseña:");

            if (USERNAME.equals(usernameInput) && PASSWORD.equals(passwordInput)) {
                JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso.");
                break;
            } else {
                attempts++;
                JOptionPane.showMessageDialog(null, "Nombre de usuario o contraseña incorrectos. Intento " + attempts + " de " + MAX_ATTEMPTS);
            }
        }

        if (attempts == MAX_ATTEMPTS) {
            JOptionPane.showMessageDialog(null, "Has agotado tus intentos. El programa se cerrará.");
            System.exit(0);
        }
    }
}