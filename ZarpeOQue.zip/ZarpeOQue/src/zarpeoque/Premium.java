
package zarpeoque;
import java.util.*;

public class Premium {

    public class ClientePremium extends Cliente {

        private double descuento;
        private int acumulaPuntos;

        public ClientePremium(String id, String metodoPago, String nombre) {
            super(id, metodoPago, nombre);
            this.descuento = 0.1; // Descuento del 10%
            this.acumulaPuntos = 0;
        }

        public void actualizarInfo(String ID) {
            this.setId(ID);
        }

        public void canjearPuntos() {
            if (acumulaPuntos >= 100) {
                int canje = acumulaPuntos / 100;
                acumulaPuntos -= canje * 100;
                System.out.println("Canje de puntos exitoso. Se aplicó un descuento de " + canje * 10 + "%.");
            } else {
                System.out.println("No tienes suficientes puntos para canjear.");
            }
        }

        public void aplicarDescuento() {
            System.out.println("Se aplicó un descuento del " + descuento * 100 + "% en la compra.");
        }

        public boolean realizarCompra(Compra compra) {
            this.historialCompras.add(compra);
            System.out.println("Compra realizada: " + compra);
            return true;
        }

        public void historialDeCompras() {
            System.out.println("Historial de compras de " + this.getId() + ":");
            for (Compra compra : this.historialCompras) {
                System.out.println(compra);
            }
        }

        public void metodosDePago() {
            System.out.println("Métodos de pago de " + this.getId() + ": "+ this.getMetodoPago());
        }
        
        public void solicitarReembolso(Compra compra) {
            List<Compra> nuevoHistorial = new ArrayList<>();

            boolean compraEncontrada = false;

            for (Compra c : historialCompras) {
                if (c.equals(compra)) {
                    compraEncontrada = true;
                } else {
                    nuevoHistorial.add(c);
                }
            }

            if (compraEncontrada) {
                historialCompras = nuevoHistorial;
                System.out.println("Reembolso solicitado y procesado para: " + compra);
            } else {
                System.out.println("La compra no se encuentra en el historial.");
            }
        }
    }
    
}//final clase
