
package zarpeoque;

import java.time.LocalDate;
import javax.swing.JOptionPane;

public abstract class Producto {
    ///////////////////////////////////////////////////////atributos de la clase
    private String nombre, ID, descripcion, categoria;
    private int cantidad;
    private boolean estado;
    private double precioNeto;//precio final, aplicando descuentos, etc
    private double precioBruto;//precio original
    private LocalDate caducidad;
    public static Object[] produc = new Object[1100];

    public Producto(String nombre, String ID, int cantidad, String descripcion, String categoria, double precioBruto,
            boolean estado, double precioNeto, LocalDate caducidad) {
        this.nombre = nombre;
        this.ID = ID;
        this.cantidad = cantidad;
        this.precioBruto = precioBruto;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.estado = estado;
        this.precioNeto = precioNeto;
        this.caducidad = caducidad;
    }//final constructor lleno

    public Producto() {
    }//final constructor vacio

    ///////////////////////////////////////////////////////////////GETS and SETS
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecioBruto() {
        return precioBruto;
    }

    public void setPrecioBruto(double precioDescuento) {
        this.precioBruto = precioDescuento;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
  
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getCategoria() {
        return categoria;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public double getPrecioNeto() {
        return precioNeto;
    }

    public void setPrecioNeto(double precioNeto) {
        this.precioNeto = precioNeto;
    }

    public LocalDate getCaducidad() {
        return caducidad;
    }

    public void setCaducidad(LocalDate caducidad) {
        this.caducidad = caducidad;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    
    //////////////////////////////////////////////////////// final GETS and SETS
    
    public int buscarProductoFila(String ID) {
        int pos = -1;
        //anidacion de for para recorrer la matriz
        for (int i = 0; i < ZarpeOQue.productos.length; i++) {
            for (int j = 0; j < ZarpeOQue.productos[i].length; j++) {
                Producto producto = ZarpeOQue.productos[i][j];
                if (producto != null && producto.getID() != null && producto.getID().equals(ID)) {
                    //si coincide con todo lo requerido y no es nulo, devuelve la fila
                    pos = i;
                    break;
                }
            }
        }
        return pos;
    }

    public int buscarProductoColumna(String ID) {
        int pos = -1;
        for (int i = 0; i < ZarpeOQue.productos.length; i++) {
            for (int j = 0; j < ZarpeOQue.productos[i].length; j++) {
                Producto producto = ZarpeOQue.productos[i][j];
                if (producto != null && producto.getID() != null && producto.getID().equals(ID)) {
                    //lo mismo que el metodo de la fila, si todo coincide devuelve la columna
                    pos = j;
                    break;
                }
            }
        }
        return pos;
    }
    
    public double obtenerPrecio(String ID) {
        double precio = 0;
        int fila = buscarProductoFila(ID);
        int columna = buscarProductoColumna(ID);
        if (fila == -1 || columna ==-1) {
            JOptionPane.showMessageDialog
        (null, "No se ha encontrado el producto");
        }//final if
        else{
            precio=ZarpeOQue.productos[fila][columna].getPrecioNeto();
        }//final else
        return precio;
    }//final metodo obtenerPrecio
    
    public void actualizarPrecio(String ID) {
        double precio;
        String name;
        int fila = buscarProductoFila(ID);
        int columna = buscarProductoColumna(ID);
        if (fila == -1 || columna ==-1) {
            JOptionPane.showMessageDialog(null,
                    "No se ha encontrado el producto");
        }//final if
        else{
            name=ZarpeOQue.productos[fila][columna].getNombre();
            precio=Double.parseDouble(JOptionPane.showInputDialog
            ("Ingrese el nuevo precio del producto '"+name+"': "));
            //despues de pedir el nuevo precio se recorre la matriz para cambiar los productos con el mismo nombre
            ZarpeOQue.productos[fila][columna].setPrecioNeto(precio);
            ZarpeOQue.productos[fila][columna].setPrecioBruto(precio);
            ListaProductos.actualizarPrecioNeto(ID, precio);
            ListaProductos.actualizarPrecioBruto(ID, precio);

        }//final else
    }//final metodo actualizarPrecio
    
    public String verDetalles(String ID) {
        String msj;
        int fila = buscarProductoFila(ID);
        int columna = buscarProductoColumna(ID);
        if (fila == -1 || columna ==-1) {
            msj="No se ha encontrado el producto";
        }//final if
        else{
            msj=ZarpeOQue.productos[fila][columna].getDescripcion();
        }//final else
        return msj; 
    }//final metodo verDetalles
    
    public int cantidadDisponible(String ID) {
        //este metodo esta pensado para que los clientes no "agarren" más de lo que hay
        //el metodo devuelve la cantidad de productos que hay en el inventario según el nombre
        //asi podemos verificar que si el cliente agarra 5 productos pero solo tenemos 4 en el inventario
        //le cobre nada más por esos 4 y le avise que no tenemos más disponibles
        int disponible = 0;
        String name;
        int fila = buscarProductoFila(ID);
        int columna = buscarProductoColumna(ID);
        if (fila == -1 || columna ==-1) {
            JOptionPane.showMessageDialog(null, "No se ha encontrado el producto.");
        }//final if
        else{
            disponible = ZarpeOQue.productos[fila][columna].getCantidad();
        }//final else
        return disponible;
    }//final metodo cantidadDisponible
    
    public void actualizarStock() {
        //este verifica la fecha de vencimiento, si caducó, entonces el estado para a false
        //con otro metodo se eliminan estos caducados
        LocalDate hoy = LocalDate.now();
        for (int i = 0; i < ZarpeOQue.productos.length; i++) {
            for (int j = 0; j < ZarpeOQue.productos[i].length; j++) {
                if (ZarpeOQue.productos[i][j] != null && ZarpeOQue.productos[i][j].getCaducidad()!= null) {
                    if (hoy.isAfter(ZarpeOQue.productos[i][j].getCaducidad())) {
                        ZarpeOQue.productos[i][j].setEstado(false);
                        ListaProductos.actualizarEstado(ZarpeOQue.productos[i][j].getID(), false);
                    }
                }
            } 
        }
    }//final metodo actualizarStock
    
    public void eliminarProductosCaducados() {
        int contador = 0;
        for (int i = 0; i < ZarpeOQue.productos.length; i++) {
            for (int j = 0; j < ZarpeOQue.productos[i].length; j++) {
                if (ZarpeOQue.productos[i][j].getID() != null || ZarpeOQue.productos[i][j].getEstado() == false ) {
                    contador+=ZarpeOQue.productos[i][j].getCantidad();
                    ZarpeOQue.productos[i][j].setCantidad(0);
                    ListaProductos.actualizarCantidad(ZarpeOQue.productos[i][j].getID(), 0);
                }//final if
            }//final for j
        }//final for i
        System.out.println("Se han eliminado: " + contador + " productos expirados.");
    }
    
    public void aplicarDescuento(String ID, double descuento) {
        double precioNuevo;
        String nombre;
        int fila = buscarProductoFila(ID);
        int columna = buscarProductoColumna(ID);
        if (fila == -1 || columna ==-1) {
            System.out.println("No se ha encontrado el producto");
        }//final if
        else{
            nombre = ZarpeOQue.productos[fila][columna].getNombre();
            //aplica el descuento a todos los productos
            ZarpeOQue.productos[fila][columna].setPrecioBruto(ZarpeOQue.productos[fila][columna].getPrecioNeto());
            precioNuevo = ZarpeOQue.productos[fila][columna].getPrecioNeto() - (ZarpeOQue.productos[fila][columna].getPrecioNeto()*(descuento/100));
            ZarpeOQue.productos[fila][columna].setPrecioNeto(precioNuevo);
            ListaProductos.actualizarPrecioNeto(ID, precioNuevo);
            ListaProductos.actualizarPrecioBruto(ID, ZarpeOQue.productos[fila][columna].getPrecioNeto());
            System.out.println("Se ha aplicado el descuento al producto '" +
                    nombre+ "'.");
        }//final else
    }//final metodo aplicarDescuento

    public void quitarDescuento(String ID) {
        String nombre;
        int fila = buscarProductoFila(ID);
        int columna = buscarProductoColumna(ID);
        if (fila == -1 || columna ==-1) {
            System.out.println("No se ha encontrado el producto");
        } else {
            nombre = ZarpeOQue.productos[fila][columna].getNombre();
            //quita el descuento a todos los productos
            ZarpeOQue.productos[fila][columna].setPrecioNeto(ZarpeOQue.productos[fila][columna].getPrecioBruto());
            ListaProductos.actualizarPrecioNeto(ID, ZarpeOQue.productos[fila][columna].getPrecioBruto());
            System.out.println("Se ha quitado el descuento al producto '" 
                    + nombre + "'.");
        }//final else
    }//final metodo quitarDescuento
    

    @Override
    public String toString() {
        return "Producto:" + "\nnombre: " + nombre + "\nID: " + ID 
                + "\ndescripcion: " + descripcion + "\ncategoria: " + categoria 
                + "\ncantidad: " + cantidad + "\nestado: " + estado 
                + "\nprecioNeto: " + precioNeto + "\nprecioBruto: " + precioBruto 
                + "\ncaducidad: " + caducidad;
    }
    
    
    
    
    
    
}//final clase

