
package zarpeoque;
import java.util.*;

public class Regular extends Cliente {
    

    public Regular(String id, String metodoPago, String nombre) {
        super(id, metodoPago, nombre);
    }

    public void actualizarInfo(String ID) {
        this.setId(ID);
    }

    public void realizarCompra() {
        int cantidadProductos = (int) (Math.random() * 10 + 1);
        System.out.println(cantidadProductos);
        Object[] productos = ZarpeOQue.productos;

        for (int i = 0; i < cantidadProductos; i++) {
            int indiceProductoAleatorio = (int) (Math.random() * productos.length);

            if (productos[indiceProductoAleatorio] != null) {
                getCarrito().add((Producto) productos[indiceProductoAleatorio]);
                productos[indiceProductoAleatorio] = null;
            }//final if
        }//final for

        System.out.println("Carrito del cliente: " + getCarrito());
    }//final metodo realizarCompra

    public void historialDeCompras() {
        System.out.println("Historial de compras de " + getId() + ":");
        for (Compra compra : this.historialCompras) {
            System.out.println(compra);
        }
    }

        public void metodosDePago() {
            System.out.println("Métodos de pago de " + getId() + ": "+ getMetodoPago());
        }

        public void solicitarReembolso(Compra compra) {
            List<Compra> nuevoHistorial = new ArrayList<>();

            boolean compraEncontrada = false;

            for (Compra c : historialCompras) {
                if (c.equals(compra)) {
                    compraEncontrada = true;
                } else {
                    nuevoHistorial.add(c);
                }
            }

            if (compraEncontrada) {
                historialCompras = nuevoHistorial;
                System.out.println("Reembolso solicitado y procesado para: " + compra);
            } else {
                System.out.println("La compra no se encuentra en el historial.");
        }
    }
}
