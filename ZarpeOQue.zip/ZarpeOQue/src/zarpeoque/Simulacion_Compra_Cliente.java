/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zarpeoque;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import javax.swing.JOptionPane;
import java.util.Random;

public class Simulacion_Compra_Cliente extends Thread {
    static CajaActiva colaInstancia = new CajaActiva();
    Queue<Cliente> colaClientes = colaInstancia.obtenerCola();
    Cliente cliente = new Cliente();
    List<Producto> carritoProductos = new ArrayList<>(); // Lista para almacenar los productos del cliente
    BodegaProducto bodega = new BodegaProducto(); // Instancia de la clase BodegaProducto
    

    public void llegar_a_Cola() {
        // Crear una copia del cliente para mantener la información del cliente original
        Cliente clienteACola = new Cliente(cliente.getId(), cliente.getMetodoPago(), cliente.getNombre());
        clienteACola.setCarrito(new ArrayList<>(carritoProductos)); // Establecer el carrito del cliente copiado
        colaClientes.offer(clienteACola); // Agregar el cliente copiado a la cola
    }

    public Cliente CrearClientes() {
        Random random = new Random();
        if (random.nextDouble() <= 0.3) {
            return new ClientePremium(JOptionPane.showInputDialog(null, "Digite su id: "),
                                       JOptionPane.showInputDialog(null, "Metodo de pago"),
                                       JOptionPane.showInputDialog(null, "Digite su nombre: "));
        } else {
            return new Regular(JOptionPane.showInputDialog(null, "Digite su id: "),
                               JOptionPane.showInputDialog(null, "Metodo de pago"),
                               JOptionPane.showInputDialog(null, "Digite su nombre: "));
        }
    }
    
        public void GenerarLosClientes(int cantidadClientes) {
        bodega.recorrerListaZarpe(); // Llamar al método para cargar todos los productos en 'allproductos'

        for (int i = 0; i < cantidadClientes; i++) {
            cliente = CrearClientes();
            System.out.println("El cliente " + cliente.getNombre() + " entra al supermercado");

            Random random = new Random();
            int min_pasillo = 1;
            int max_pasillo = 5;
            List<Integer> pasillosVisitados = new ArrayList<>(); // Lista para llevar un seguimiento de los pasillos visitados por el cliente

            System.out.println("El cliente " + cliente.getNombre() + " buscará productos en varios pasillos");

            while (pasillosVisitados.size() < max_pasillo) {
                int pasilloActual = min_pasillo + random.nextInt((max_pasillo - min_pasillo) + 1);

                if (!pasillosVisitados.contains(pasilloActual)) {
                    pasillosVisitados.add(pasilloActual);

                    System.out.println("El cliente " + cliente.getNombre() + " está en el pasillo " + pasilloActual);
                    List<Producto> productosPasilloActual = obtenerProductosDelPasillo(pasilloActual);
                    mostrarCatalogoProductosPorPasillo(pasilloActual);
                    int cantidadProductosAComprar = 1 + random.nextInt(2); // Se eligen hasta 2 productos

                    boolean encontrado = false; // Bandera para verificar si se encontraron productos en este pasillo

                    for (int k = 0; k < cantidadProductosAComprar; k++) {
                        if (!productosPasilloActual.isEmpty()) {
                            int indiceProductoAleatorio = random.nextInt(productosPasilloActual.size());
                            Producto productoElegido = productosPasilloActual.get(indiceProductoAleatorio);
                            carritoProductos.add(productoElegido);
                            System.out.println("Agregado al carrito: " + productoElegido.getNombre());
                            encontrado = true; // Marcamos que se encontraron productos en este pasillo
                        } else {
                            System.out.println("El pasillo está vacío.");
                            break;
                        }
                    }

                    // Después del ciclo de productos en el pasillo
                    if (!encontrado) {
                        System.out.println("No se encontraron productos en el pasillo " + pasilloActual);
                    }
                }
            }

            // El cliente va a pagar sus productos a alguna caja
            llegar_a_Cola();

            // Limpiar el carrito de compras después de agregar el cliente a la cola
            carritoProductos.clear();
        }
    }
    private List<Producto> obtenerProductosDelPasillo(int pasillo) {
        switch (pasillo) {
            case 1: return bodega.bodegaBebidas;
            case 2: return bodega.bodegaCongealdos;
            case 3: return bodega.bodegaLicor;
            case 4: return bodega.bodegaCarnes;
            case 5: return bodega.bodegaEnlatados;
            case 6: return bodega.bodegaFarmaco;
            case 7: return bodega.bodegaFrutaverdura;
            case 8: return bodega.bodegaHarina;
            case 9: return bodega.bodegaSnack;
            case 10: return bodega.bodegaLegumbre;
            case 11: return bodega.bodegaLacteo;
            default: return new ArrayList<>(); // Devuelve una lista vacía si no se encuentra el pasillo
        }
    }
    public void mostrarCatalogoProductosPorPasillo(int pasillo) {
        List<Producto> productosPasillo = obtenerProductosDelPasillo(pasillo);

        StringBuilder mensaje = new StringBuilder("Catálogo de productos en el pasillo " + pasillo + ":\n");

        for (Producto producto : productosPasillo) {
            mensaje.append("Nombre: ").append(producto.getNombre()).append("\n");
            mensaje.append("Precio: ").append(producto.getPrecioBruto()).append("\n");
            mensaje.append("----------------------\n");
        }

        JOptionPane.showMessageDialog(null, mensaje.toString());
    }

    


    public void run() {
        GenerarLosClientes(2);

        Cajero caja1 = new Cajero(111, 30, "Cajero 1", 'M');
        Cajero caja2 = new Cajero(112, 28, "Cajero 2", 'F');

        // Mientras ambas cajas no estén disponibles, continúa el bucle
        while (caja1.isDisponible() || caja2.isDisponible()) {
            // Si la caja 1 está disponible y hay clientes en la cola
            if (caja1.isDisponible() && colaInstancia.esVacia()) {
                caja1.setDisponible(false); // Marcar la caja como ocupada
                colaInstancia.Caja_Uno(); //Llamar al cliente siguiente en la cola
                JOptionPane.showMessageDialog(null, caja1.Mostrar_CompraFinal()); // Mostrar detalles de la compra
                caja1.setDisponible(true); // Marcar la caja como disponible nuevamente
            }

            // Si la caja 2 está disponible y hay clientes en la cola
            if (caja2.isDisponible() && colaInstancia.esVacia()) {
                caja2.setDisponible(false); // Marcar la caja como ocupada
                colaInstancia.caja_dos();
                JOptionPane.showMessageDialog(null, caja2.Mostrar_CompraFinal()); // Mostrar detalles de la compra
                caja2.setDisponible(true); // Marcar la caja como disponible nuevamente
            }

            try {
                // Simula el tiempo que tarda en atender a un cliente
                Thread.sleep(2000); // 2000 milisegundos = 2 segundos
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}