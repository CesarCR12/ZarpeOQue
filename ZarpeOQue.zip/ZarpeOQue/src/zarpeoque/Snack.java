
package zarpeoque;

import javax.swing.JOptionPane;
import java.time.LocalDate;

public class Snack extends Producto{

    public Snack(String nombre, String ID, String descripcion,String categoria,double precioBruto, boolean estado, double precioNeto, LocalDate caducidad) {
        super(nombre, ID, descripcion,categoria,precioBruto ,estado, precioNeto, caducidad);
    }//final constructor lleno

    public Snack() {
    }//final construcutor vacio
    
    public static void instanciarSnacks(){
        for (int i = 0; i < 25; i++) {
            ZarpeOQue.productos[1][i] = new Snack("RANCHITAS", "1", "RANCHITAS NACHO QUESO 150g","snack", 1050, true, 1050, LocalDate.now().plusDays(2));
        }
        for (int i = 25; i < 50; i++) {
            ZarpeOQue.productos[1][i] = new Snack("CHIRULITOS", "2", "CHIRULITOS TOSTY MEDIANOS 100g","snack", 850, true, 850, LocalDate.now().plusDays(2));
        }
        for (int i = 50; i < 75; i++) {
            ZarpeOQue.productos[1][i] = new Snack("PLATANITOS", "3", "SOLDANZA PLATANITOS 180g","snack", 1050, true, 1050, LocalDate.now().plusDays(2));
        }
        for (int i = 75; i < 100; i++) {
            ZarpeOQue.productos[1][i] = new Snack();
        }    
    }//final metodo instanciarSnacks
    
    public static void pedirMasSnacks() {
        int contador = 0;
        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[1][i].getID() == null) {
                contador++;
            }
        }

        if (contador == 100) {
            JOptionPane.showMessageDialog(null, "El inventario está en su capacidad máxima.");
            return;
        }

        int categoria = Integer.parseInt(JOptionPane.showInputDialog(
                "¿Qué producto quiere agregar?\n 1- Ranchitas \n 2- Chirulitos \n 3- Platanitos \n 4- Otro \n 5- Cancelar"));

        if (categoria == 5) {
            JOptionPane.showMessageDialog(null, "Saliendo...");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("El inventario actual es: " + (100 - contador) + "/100\nCuantos productos quiere agregar?"));
        System.out.println("AJAAAAAAAA "+((100 - contador)+cantidad));//TEST
        if (((100 - contador)+cantidad) > 100) {
            JOptionPane.showMessageDialog(null, "No hay suficiente espacio en el inventario.");
            return;
        }

        agregarProductos(categoria, cantidad);
    }

    private static void agregarProductos(int categoria, int cantidad) {
        String nombre, id, descrip;
        double precio;

        switch (categoria) {
            case 1:
                nombre = "RANCHITAS";
                id = "1";
                descrip = "RANCHITAS NACHO QUESO 150g";
                precio = 1050;
                break;
            case 2:
                nombre = "CHIRULITOS";
                id = "2";
                descrip = "CHIRULITOS TOSTY MEDIANOS 100g";
                precio = 850;
                break;
            case 3:
                nombre = "PLATANITOS";
                id = "3";
                descrip = "SOLDANZA PLATANITOS 180g";
                precio = 1050;
                break;
            case 4:
                nombre = JOptionPane.showInputDialog("Ingrese el nombre del snack :").toUpperCase();
                id = JOptionPane.showInputDialog("Ingrese el ID del producto:");
                descrip = JOptionPane.showInputDialog("Ingrese la descripción del snack:").toUpperCase();
                precio = Double.parseDouble(JOptionPane.showInputDialog("Digite el precio del snack:"));
                break;
            default:
                JOptionPane.showMessageDialog(null, "Seleccione una opción válida.");
                return;
        }

        for (int i = 0; i < 100; i++) {
            if (ZarpeOQue.productos[1][i].getID() == null) {
                ZarpeOQue.productos[1][i] = new Snack(nombre, id, descrip,"snack", precio, true, precio, LocalDate.now().plusDays(2));
                cantidad--;
                if (cantidad == 0) {
                    break;
                }
            }
        }
    }
}//final clase
