
package zarpeoque;

public class Start {
    
    
    public static void instancias(){
        Congelado.instanciarCongelados();
        Snack.instanciarSnacks();
        Harina.instanciarHarinas();
        Lacteo.instanciarLacteos();
        Licor.instanciarLicor();
        Carne.instanciarCarnes();
        Enlatado.instanciarEnlatados();
        Legumbre.instanciarLegumbres();
        Farmaco.instanciarFarmacos();
        Bebida.instanciarBebidas();
        Fruta_Verdura.instanciarFruta_Verduras();
    }//final metodo instancias
}
