/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zarpeoque;

/**
 *
 * @author franv
 */
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class TablaProducto extends JFrame {
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    
    public TablaProducto(BodegaProducto bodega) {
        setTitle("Productos en Bodega");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 200, 600, 400);

        modeloTabla = new DefaultTableModel();
        tabla = new JTable(modeloTabla);

        String[] columnas = {"Nombre", "Precio", "Descripción", "Caducidad", "Estado"};
        modeloTabla.setColumnIdentifiers(columnas);

        // Arreglo para almacenar IDs de productos ya mostrados
        List<String> idsMostrados = new ArrayList<>();

        for (Producto producto : bodega.allproductos) {
            if (!idsMostrados.contains(producto.getID())) {
                Object[] fila = {producto.getNombre(), producto.getPrecioBruto(), producto.getDescripcion(),producto.getCaducidad(),producto.getEstado()};
                modeloTabla.addRow(fila);
                idsMostrados.add(producto.getID());
            }
        }

        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane);

        setVisible(true);
    }
}    