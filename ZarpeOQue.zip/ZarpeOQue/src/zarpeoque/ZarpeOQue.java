
package zarpeoque;



public class ZarpeOQue {

    static Producto[][] productos = new Producto[11][6];
    
    public static void main(String[] args) {
        Login.login();
        
        Producto producto = new Snack();
        BodegaProducto bodega = new BodegaProducto();
       
        Start.instancias();

        
        Snack.pedirMasSnacks();
        bodega.recorrerListaZarpe();
        
        ListaProductos lista = new ListaProductos();
        lista.setVisible(true);
        lista.recuperar();
        
        /*
        Bodeguero toledo = new Bodeguero(2,2,"n",'m');
        toledo.verInventario();*/
        
       
        
        // Llamada al método GenerarLosClientes con un número específico de clientes
     
      
        
        
        //Simulacion_Compra_Cliente compra = new Simulacion_Compra_Cliente();
        //compra.start();
        
  
        //bodega.imprimirProductosPorCategoria("bebida");
        
       
        
        /*
        for (int i = 0; i < 11; i++) {
            for (int j = 0; j < 1; j++) {
                System.out.println(ZarpeOQue.productos[i][j]+"HOLAAAA123");
            } 
        }

        System.out.println("Disponible: "+producto.obtenerPrecio("1"));
        Snack.pedirMasSnacks();
        Snack.pedirMasSnacks();
        Harina.pedirMasHarinas();*/
    }//final main
}//final clase
