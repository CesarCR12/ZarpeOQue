
package zarpeoque;


public class ZarpeOQue {

    static Producto[][] productos = new Producto[11][6];
    static Ganancias reporte = new Ganancias();

    public static void main(String[] args) {
        Start.app();
    }//final main
}//final clase

